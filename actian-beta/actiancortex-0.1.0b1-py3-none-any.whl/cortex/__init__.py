############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Cortex Vector Database Python Client SDK."""

from cortex.async_client import AsyncCortexClient
from cortex.client import CortexClient
from cortex.filters import Field, Filter
from cortex.models.types import (
    CollectionConfig,
    CollectionInfo,
    CollectionState,
    CollectionStats,
    CortexError,
    DistanceMetric,
    HnswConfig,
    IndexAlgorithm,
    Payload,
    PointId,
    PointRecord,
    PointStruct,
    SearchResult,
    Vector,
)

__version__ = "0.1.0b1"

__all__ = [
    # Clients
    "CortexClient",
    "AsyncCortexClient",
    # Filters
    "Filter",
    "Field",
    # Models - Core Types
    "CollectionConfig",
    "CollectionInfo",
    "CollectionStats",
    "CollectionState",
    "HnswConfig",
    # Models - Point Types
    "SearchResult",
    "PointRecord",
    "PointStruct",
    "PointId",
    # Models - Vector/Payload
    "Vector",
    "Payload",
    # Enums
    "DistanceMetric",
    "IndexAlgorithm",
    # Errors
    "CortexError",
    # Version
    "__version__",
]
