############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Cortex utilities package.

This module provides utility functions and constants for the Cortex client.
Note: Batching is now handled automatically by the SmartBatcher and server.
"""

__all__ = []
