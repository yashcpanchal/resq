############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Type-safe Filter DSL for building search queries.

Provides a fluent builder pattern to construct filter expressions that
compile to the JSON format expected by the Cortex server. This catches
structural errors at build time rather than getting "Bad Request" from server.

Example:
    from cortex.filters import Filter, Field

    # Simple equality filter
    filter = Filter().must(Field("category").eq("electronics"))

    # Complex filter with multiple conditions
    filter = (
        Filter()
        .must(Field("category").eq("electronics"))
        .must(Field("price").lt(1000))
        .should(Field("in_stock").eq(True))
        .must_not(Field("discontinued").eq(True))
    )

    # Compiles to JSON for the gRPC call
    json_str = filter.to_json()

Cortex Filter Format:
    - Equality: {"field": "value"} or {"field": {"$eq": value}}
    - Greater than: {"field": {"$gt": value}}
    - Greater than or equal: {"field": {"$gte": value}}
    - Less than: {"field": {"$lt": value}}
    - Less than or equal: {"field": {"$lte": value}}
    - Not equal: {"field": {"$ne": value}}
    - Range: {"field": {"$gte": min, "$lte": max}}

    System fields: _id, _uuid, _label, _createTime, _updateTime
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional, Union


class ConditionType(str, Enum):
    """Types of filter conditions."""

    EQ = "eq"
    NE = "ne"
    GT = "gt"
    GTE = "gte"
    LT = "lt"
    LTE = "lte"
    IN = "in"
    NOT_IN = "not_in"
    RANGE = "range"
    IS_NULL = "is_null"
    IS_NOT_NULL = "is_not_null"
    LIKE = "like"
    NOT_LIKE = "not_like"


@dataclass
class Condition:
    """A single filter condition on a field.

    Represents comparisons like: field == value, field > value, etc.
    Outputs the exact format expected by the Cortex server.
    """

    key: str
    condition_type: ConditionType
    value: Any = None
    gte: Optional[Any] = None  # For range queries
    lte: Optional[Any] = None  # For range queries
    gt: Optional[Any] = None  # For range queries
    lt: Optional[Any] = None  # For range queries

    def to_dict(self) -> dict:
        """Convert to dictionary representation.

        Cortex Filter Format:
        - Equality: {"field": "value"} or {"field": {"$eq": value}}
        - Comparison: {"field": {"$gte": value}}
        - Range: {"field": {"$gte": min, "$lte": max}}
        """
        if self.condition_type == ConditionType.RANGE:
            ops = {}
            if self.gt is not None:
                ops["$gt"] = self.gt
            if self.gte is not None:
                ops["$gte"] = self.gte
            if self.lt is not None:
                ops["$lt"] = self.lt
            if self.lte is not None:
                ops["$lte"] = self.lte
            return {self.key: ops}
        elif self.condition_type == ConditionType.EQ:
            # Simple equality: {"field": "value"}
            return {self.key: self.value}
        elif self.condition_type == ConditionType.NE:
            return {self.key: {"$ne": self.value}}
        elif self.condition_type == ConditionType.GT:
            return {self.key: {"$gt": self.value}}
        elif self.condition_type == ConditionType.GTE:
            return {self.key: {"$gte": self.value}}
        elif self.condition_type == ConditionType.LT:
            return {self.key: {"$lt": self.value}}
        elif self.condition_type == ConditionType.LTE:
            return {self.key: {"$lte": self.value}}
        elif self.condition_type == ConditionType.IN:
            return {self.key: {"$in": self.value}}
        elif self.condition_type == ConditionType.NOT_IN:
            return {self.key: {"$nin": self.value}}
        elif self.condition_type == ConditionType.IS_NULL:
            return {self.key: None}
        elif self.condition_type == ConditionType.IS_NOT_NULL:
            return {self.key: {"$ne": None}}
        elif self.condition_type == ConditionType.LIKE:
            return {self.key: {"$like": self.value}}
        elif self.condition_type == ConditionType.NOT_LIKE:
            return {self.key: {"$notlike": self.value}}
        else:
            return {self.key: self.value}


class Field:
    """Builder for field-level conditions.

    Example:
        condition = Field("price").gt(100)
        condition = Field("status").eq("active")
        condition = Field("_id").gte(10)  # System field
    """

    def __init__(self, name: str):
        """Initialize field builder.

        Args:
            name: The field name to filter on.
                  For system fields, use: _id, _uuid, _label, _createTime, _updateTime
        """
        self._name = name

    def eq(self, value: Any) -> Condition:
        """Equal to value."""
        return Condition(key=self._name, condition_type=ConditionType.EQ, value=value)

    def ne(self, value: Any) -> Condition:
        """Not equal to value."""
        return Condition(key=self._name, condition_type=ConditionType.NE, value=value)

    def gt(self, value: Union[int, float]) -> Condition:
        """Greater than value."""
        return Condition(key=self._name, condition_type=ConditionType.GT, value=value)

    def gte(self, value: Union[int, float]) -> Condition:
        """Greater than or equal to value."""
        return Condition(key=self._name, condition_type=ConditionType.GTE, value=value)

    def lt(self, value: Union[int, float]) -> Condition:
        """Less than value."""
        return Condition(key=self._name, condition_type=ConditionType.LT, value=value)

    def lte(self, value: Union[int, float]) -> Condition:
        """Less than or equal to value."""
        return Condition(key=self._name, condition_type=ConditionType.LTE, value=value)

    def is_in(self, values: list[Any]) -> Condition:
        """Value is in the list."""
        return Condition(key=self._name, condition_type=ConditionType.IN, value=values)

    def not_in(self, values: list[Any]) -> Condition:
        """Value is not in the list."""
        return Condition(key=self._name, condition_type=ConditionType.NOT_IN, value=values)

    def range(
        self,
        gt: Optional[Union[int, float]] = None,
        gte: Optional[Union[int, float]] = None,
        lt: Optional[Union[int, float]] = None,
        lte: Optional[Union[int, float]] = None,
    ) -> Condition:
        """Value is within range.

        Args:
            gt: Greater than (exclusive lower bound)
            gte: Greater than or equal (inclusive lower bound)
            lt: Less than (exclusive upper bound)
            lte: Less than or equal (inclusive upper bound)

        Example:
            Field("price").range(gte=50, lte=200)  # 50 <= price <= 200
            Field("price").range(gt=0, lt=100)     # 0 < price < 100
        """
        if gt is None and gte is None and lt is None and lte is None:
            raise ValueError("At least one bound must be specified")
        return Condition(
            key=self._name,
            condition_type=ConditionType.RANGE,
            gt=gt,
            gte=gte,
            lt=lt,
            lte=lte,
        )

    def between(
        self,
        lower: Union[int, float],
        upper: Union[int, float],
        inclusive: bool = True,
    ) -> Condition:
        """Value is between lower and upper bounds.

        Args:
            lower: Lower bound
            upper: Upper bound
            inclusive: If True, includes bounds (gte/lte). If False, excludes (gt/lt).
        """
        if inclusive:
            return self.range(gte=lower, lte=upper)
        else:
            return self.range(gt=lower, lt=upper)

    def like(self, pattern: str) -> Condition:
        """Pattern matching (SQL LIKE)."""
        return Condition(key=self._name, condition_type=ConditionType.LIKE, value=pattern)

    def not_like(self, pattern: str) -> Condition:
        """Negated pattern matching."""
        return Condition(key=self._name, condition_type=ConditionType.NOT_LIKE, value=pattern)

    def is_null(self) -> Condition:
        """Field is null/missing."""
        return Condition(key=self._name, condition_type=ConditionType.IS_NULL)

    def is_not_null(self) -> Condition:
        """Field is not null/exists."""
        return Condition(key=self._name, condition_type=ConditionType.IS_NOT_NULL)


@dataclass
class Filter:
    """Builder for complex filter expressions.

    Supports must (AND), should (OR), and must_not (NOT) clauses.

    Example:
        filter = (
            Filter()
            .must(Field("category").eq("books"))
            .must(Field("price").lt(50))
            .should(Field("author").eq("Smith"))
            .must_not(Field("out_of_print").eq(True))
        )
    """

    _must: list[Condition] = field(default_factory=list)
    _should: list[Condition] = field(default_factory=list)
    _must_not: list[Condition] = field(default_factory=list)

    def must(self, condition: Condition) -> "Filter":
        """Add a required condition (AND logic).

        Args:
            condition: Condition that must match

        Returns:
            Self for chaining
        """
        self._must.append(condition)
        return self

    def should(self, condition: Condition) -> "Filter":
        """Add an optional condition (OR logic).

        Args:
            condition: Condition that should match

        Returns:
            Self for chaining
        """
        self._should.append(condition)
        return self

    def must_not(self, condition: Condition) -> "Filter":
        """Add a negated condition (NOT logic).

        Args:
            condition: Condition that must not match

        Returns:
            Self for chaining
        """
        self._must_not.append(condition)
        return self

    def __and__(self, other: "Filter") -> "Filter":
        """Combine filters with AND (& operator).

        Example:
            combined = filter1 & filter2
        """
        result = Filter()
        result._must = self._must + other._must
        result._should = self._should + other._should
        result._must_not = self._must_not + other._must_not
        return result

    def __or__(self, other: "Filter") -> "Filter":
        """Combine filters with OR (| operator).

        Note: This wraps both filters in a should clause.
        """
        result = Filter()
        result._should = self._must + other._must
        return result

    def is_empty(self) -> bool:
        """Check if filter has no conditions."""
        return not self._must and not self._should and not self._must_not

    def to_dict(self) -> dict:
        """Convert filter to dictionary representation.

        Cortex Filter Format:
        - Single condition: {"field": value} or {"field": {"$op": value}}
        - Multiple AND: {"$and": [...]}
        - Multiple OR: {"$or": [...]}

        Returns:
            Dictionary matching the Cortex filter schema
        """
        parts = []

        # must = AND logic - all conditions must match
        if self._must:
            if len(self._must) == 1:
                parts.append(self._must[0].to_dict())
            else:
                parts.append({"$and": [c.to_dict() for c in self._must]})

        # should = OR logic - at least one must match
        if self._should:
            parts.append({"$or": [c.to_dict() for c in self._should]})

        # must_not = NOT logic - none should match
        for c in self._must_not:
            d = c.to_dict()
            for k, v in d.items():
                if isinstance(v, dict):
                    parts.append(d)
                else:
                    parts.append({k: {"$ne": v}})
                break

        if not parts:
            return {}
        elif len(parts) == 1:
            return parts[0]
        else:
            return {"$and": parts}

    def to_dict_or_none(self) -> Optional[dict]:
        """Convert filter to dictionary or None if empty."""
        if self.is_empty():
            return None
        return self.to_dict()

    def to_json(self) -> str:
        """Convert filter to JSON string for gRPC request.

        Returns:
            Compact JSON string representation, empty string if no conditions
        """
        if self.is_empty():
            return ""
        return json.dumps(self.to_dict(), separators=(",", ":"))

    def to_json_or_none(self) -> Optional[str]:
        """Convert filter to JSON string or None if empty."""
        if self.is_empty():
            return None
        return json.dumps(self.to_dict(), separators=(",", ":"))

    def __str__(self) -> str:
        """String representation showing the JSON output."""
        if self.is_empty():
            return "Filter(empty)"
        return f"Filter({self.to_json()})"

    def __repr__(self) -> str:
        parts = []
        if self._must:
            parts.append(f"must={len(self._must)}")
        if self._should:
            parts.append(f"should={len(self._should)}")
        if self._must_not:
            parts.append(f"must_not={len(self._must_not)}")
        return f"Filter({', '.join(parts) or 'empty'})"

    def __bool__(self) -> bool:
        """Allow truthiness check: if filter: ..."""
        return not self.is_empty()

    def copy(self) -> "Filter":
        """Create a copy of this filter."""
        new_filter = Filter()
        new_filter._must = self._must.copy()
        new_filter._should = self._should.copy()
        new_filter._must_not = self._must_not.copy()
        return new_filter

    def clear(self) -> "Filter":
        """Clear all conditions from this filter."""
        self._must.clear()
        self._should.clear()
        self._must_not.clear()
        return self
