############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Pydantic models wrapping proto types for type-safe Python interface."""

from __future__ import annotations

from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class DistanceMetric(str, Enum):
    """Distance metric for vector similarity search."""

    COSINE = "COSINE"
    EUCLIDEAN = "EUCLIDEAN"
    DOT = "DOT"


class IndexAlgorithm(str, Enum):
    """Index algorithm for vector storage."""

    HNSW = "HNSW"
    FLAT = "FLAT"


class IndexDriver(str, Enum):
    """Index driver implementation."""

    FAISS = "FAISS"


class StorageType(str, Enum):
    """Storage backend type."""

    BTRIEVE_SPACE = "BTRIEVE_SPACE"


class CollectionState(str, Enum):
    """State of a collection."""

    READY = "READY"
    LOADING = "LOADING"
    REBUILDING = "REBUILDING"
    ERROR = "ERROR"


class HnswConfig(BaseModel):
    """HNSW index configuration."""

    m: int = Field(default=16, description="Number of edges per node in the index graph")
    ef_construct: int = Field(
        default=200, description="Neighbors to consider during index building"
    )
    ef_search: int = Field(default=50, description="Neighbors to consider during search")


class CollectionConfig(BaseModel):
    """Configuration for creating a collection."""

    dimension: int = Field(..., description="Vector dimension", ge=1)
    distance_metric: DistanceMetric = Field(default=DistanceMetric.COSINE)
    index_driver: IndexDriver = Field(default=IndexDriver.FAISS)
    index_algorithm: IndexAlgorithm = Field(default=IndexAlgorithm.HNSW)
    storage_type: StorageType = Field(default=StorageType.BTRIEVE_SPACE)
    hnsw_config: Optional[HnswConfig] = Field(default=None)
    config_json: Optional[str] = Field(default=None, description="Driver-specific JSON config")


class Vector(BaseModel):
    """Vector data container."""

    data: list[float] = Field(..., description="Vector values")
    dimension: int = Field(..., description="Vector dimension", ge=1)

    @classmethod
    def from_list(cls, data: list[float]) -> "Vector":
        """Create Vector from a list of floats."""
        return cls(data=data, dimension=len(data))

    def to_numpy(self) -> Any:
        """Convert to numpy array."""
        import numpy as np

        return np.array(self.data, dtype=np.float32)


class Payload(BaseModel):
    """Metadata payload as JSON."""

    json_data: str = Field(default="{}", description="Payload in JSON format", alias="json")

    model_config = {"populate_by_name": True}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Payload":
        """Create Payload from a dictionary."""
        import json

        return cls(json_data=json.dumps(data))

    def to_dict(self) -> dict[str, Any]:
        """Parse JSON payload to dictionary."""
        import json

        return json.loads(self.json_data) if self.json_data else {}


class SearchResult(BaseModel):
    """Vector search result.

    Attributes:
        id: Vector ID (primary identifier)
        score: Distance score (EUCLIDEAN: lower=closer, COSINE/DOT: higher=better)
        payload: Optional metadata returned with the result
        vector: Optional vector data if with_vector=True was requested

    Properties:
        point_id: Alias for id
        distance: Alias for score - for distance-based access patterns

    Examples:
        >>> results = await client.search(collection, query_vector, top_k=10)
        >>> for result in results:
        ...     print(f"ID: {result.id}, Score: {result.score}")
    """

    id: int = Field(..., description="Vector ID (primary identifier)")
    score: float = Field(..., description="Distance/similarity score")
    payload: Optional[dict[str, Any]] = Field(default=None, description="Metadata payload")
    vector: Optional[list[float]] = Field(default=None, description="Vector data")

    @property
    def point_id(self) -> int:
        """Alias for id."""
        return self.id

    @property
    def distance(self) -> float:
        """Alias for score - distance/similarity value."""
        return self.score

    def __repr__(self) -> str:
        parts = [f"id={self.id}", f"score={self.score:.4f}"]
        if self.payload:
            parts.append(f"payload={self.payload}")
        return f"SearchResult({', '.join(parts)})"

    def __str__(self) -> str:
        result = {"id": self.id, "distance": self.score}
        if self.payload:
            result["entity"] = self.payload
        return str(result)


# Type alias for point identifiers

PointId = int


class PointStruct(BaseModel):
    """A point containing an ID, vector, and optional payload.

    This is the primary data structure for inserting vectors.

    Attributes:
        id: Point identifier (integer ID)
        vector: Vector data as list of floats
        payload: Optional metadata dictionary

    Examples:
        >>> # Create point with integer ID
        >>> point = PointStruct(id=0, vector=[0.1, 0.2, 0.3], payload={"category": "A"})

        >>> # Batch insert
        >>> points = [
        ...     PointStruct(id=1, vector=[0.1, 0.2], payload={"name": "doc1"}),
        ...     PointStruct(id=2, vector=[0.3, 0.4], payload={"name": "doc2"}),
        ... ]
        >>> client.upsert(collection, points)
    """

    id: int = Field(..., description="Point ID (integer)")
    vector: list[float] = Field(..., description="Vector data")
    payload: Optional[dict[str, Any]] = Field(default=None, description="Metadata payload")

    @property
    def point_id(self) -> int:
        """Alias for id."""
        return self.id

    def __repr__(self) -> str:
        return (
            f"PointStruct(id={self.id}, vector=[{len(self.vector)} dims], payload={self.payload})"
        )


class PointRecord(BaseModel):
    """A vector record with its ID, vector data, and payload.

    Used in scroll() and get_many() operations.

    Attributes:
        id: Vector ID (integer)
        vector: Vector data (optional, only if with_vectors=True)
        payload: Metadata payload (optional, only if with_payload=True)
    """

    id: int = Field(..., description="Vector ID (integer)")
    vector: Optional[list[float]] = Field(default=None, description="Vector data")
    payload: Optional[dict[str, Any]] = Field(default=None, description="Metadata payload")

    @property
    def point_id(self) -> int:
        """Alias for id."""
        return self.id


class CollectionInfo(BaseModel):
    """Collection information for describe_collection().

    Models the collection configuration and status information.
    collection information.

    Attributes:
        name: Collection name
        dimension: Vector dimension
        distance_metric: Distance metric (COSINE, EUCLIDEAN, DOT)
        storage_type: Storage backend type
        state: Current collection state
        vectors_count: Total number of vectors
        indexed_vectors_count: Number of indexed vectors
    """

    name: str = Field(..., description="Collection name")
    dimension: int = Field(..., description="Vector dimension")
    distance_metric: DistanceMetric = Field(default=DistanceMetric.COSINE)
    storage_type: StorageType = Field(default=StorageType.BTRIEVE_SPACE)
    index_algorithm: IndexAlgorithm = Field(default=IndexAlgorithm.HNSW)
    state: CollectionState = Field(default=CollectionState.READY)
    vectors_count: int = Field(default=0, description="Total vectors")
    indexed_vectors_count: int = Field(default=0, description="Indexed vectors")
    hnsw_config: Optional[HnswConfig] = Field(default=None)


class CollectionStats(BaseModel):
    """Collection statistics."""

    total_vectors: int = Field(default=0)
    indexed_vectors: int = Field(default=0)
    deleted_vectors: int = Field(default=0)
    storage_bytes: int = Field(default=0)
    index_memory_bytes: int = Field(default=0)


class Status(BaseModel):
    """Operation status response."""

    code: int = Field(default=0, description="0 = success, negative = error")
    message: str = Field(default="", description="Error message if code != 0")

    @property
    def ok(self) -> bool:
        """Check if operation was successful."""
        return self.code == 0

    @property
    def is_ok(self) -> bool:
        """Alias for ok."""
        return self.code == 0

    def raise_for_status(self) -> None:
        """Raise exception if operation failed."""
        if not self.ok:
            raise CortexError(self.code, self.message)


class CortexError(Exception):
    """Exception raised for Cortex operation failures."""

    def __init__(self, code: int, message: str):
        self.code = code
        self.message = message
        super().__init__(f"Cortex error {code}: {message}")
