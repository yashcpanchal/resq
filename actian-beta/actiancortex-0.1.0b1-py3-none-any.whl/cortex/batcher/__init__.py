############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Smart Batcher subpackage - Automatic batching for high-throughput ingestion."""

from cortex.batcher.smart_batcher import BatcherConfig, SmartBatcher

__all__ = [
    "SmartBatcher",
    "BatcherConfig",
]
