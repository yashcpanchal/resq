############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Smart Batcher for automatic batching of vector upserts.

Implements an asynchronous buffering queue that batches individual upsert
calls into optimal BatchUpsertRequest calls based on configurable triggers:
- Size limit: Number of vectors in buffer
- Byte limit: Estimated payload size
- Time limit: Maximum time before flush

This provides the ease of single-item API with bulk throughput characteristics.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Optional, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")


@dataclass
class BatcherConfig:
    """Configuration for the smart batcher."""

    size_limit: int = 100
    """Maximum number of items before triggering a flush."""

    byte_limit: int = 4 * 1024 * 1024  # 4MB
    """Maximum estimated payload size in bytes before triggering a flush."""

    time_limit_ms: int = 100
    """Maximum time in milliseconds before triggering a flush."""

    max_concurrent_flushes: int = 3
    """Maximum number of concurrent flush operations."""


@dataclass
class BatchItem:
    """Single item in the batch queue."""

    collection_name: str
    id: int
    vector: list[float]
    payload: Optional[dict[str, Any]]
    future: asyncio.Future[None]
    estimated_bytes: int = 0

    def __post_init__(self):
        # Estimate bytes: 4 bytes per float + JSON overhead
        self.estimated_bytes = len(self.vector) * 4 + len(str(self.payload or {}))


class SmartBatcher:
    """Async smart batcher for vector upserts.

    Buffers individual upsert calls and flushes them as batches when:
    - Buffer size reaches `size_limit`
    - Buffer byte size reaches `byte_limit`
    - Time since first item reaches `time_limit_ms`

    Example:
        async def batch_upsert(items):
            # Call gRPC BatchUpsert
            ...

        batcher = SmartBatcher(batch_upsert)
        await batcher.start()

        # These are batched automatically
        future1 = await batcher.add("coll", 1, [0.1, 0.2], {"key": "value"})
        future2 = await batcher.add("coll", 2, [0.3, 0.4], None)

        # Wait for completion
        await future1
        await future2

        await batcher.stop()
    """

    def __init__(
        self,
        flush_callback: Callable[[str, list[BatchItem]], Awaitable[None]],
        config: Optional[BatcherConfig] = None,
    ):
        """Initialize the smart batcher.

        Args:
            flush_callback: Async function called to flush a batch.
                           Signature: (collection_name, items) -> None
            config: Batcher configuration
        """
        self._flush_callback = flush_callback
        self._config = config or BatcherConfig()

        # Buffer: collection_name -> list of items
        self._buffers: dict[str, list[BatchItem]] = {}
        self._buffer_bytes: dict[str, int] = {}
        self._first_item_time: dict[str, float] = {}

        self._lock = asyncio.Lock()
        self._worker_task: Optional[asyncio.Task] = None
        self._stop_event = asyncio.Event()
        self._flush_semaphore = asyncio.Semaphore(self._config.max_concurrent_flushes)

    async def start(self) -> None:
        """Start the background flush worker."""
        if self._worker_task is not None:
            return

        self._stop_event.clear()
        self._worker_task = asyncio.create_task(self._worker())
        logger.debug("Smart batcher started")

    async def stop(self, flush_remaining: bool = True) -> None:
        """Stop the batcher and optionally flush remaining items.

        Args:
            flush_remaining: If True, flush all remaining items before stopping
        """
        self._stop_event.set()

        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
            self._worker_task = None

        if flush_remaining:
            await self._flush_all(await_flush=True)

        logger.debug("Smart batcher stopped")

    async def add(
        self,
        collection_name: str,
        id: int,
        vector: list[float],
        payload: Optional[dict[str, Any]] = None,
    ) -> asyncio.Future[None]:
        """Add an item to the batch queue.

        Args:
            collection_name: Target collection
            id: Vector ID
            vector: Vector data
            payload: Optional JSON payload

        Returns:
            Future that resolves when the item is flushed to the server.
        """
        loop = asyncio.get_event_loop()
        future: asyncio.Future[None] = loop.create_future()

        item = BatchItem(
            collection_name=collection_name,
            id=id,
            vector=vector,
            payload=payload,
            future=future,
        )

        async with self._lock:
            # Initialize buffer for collection if needed
            if collection_name not in self._buffers:
                self._buffers[collection_name] = []
                self._buffer_bytes[collection_name] = 0
                self._first_item_time[collection_name] = asyncio.get_event_loop().time()

            self._buffers[collection_name].append(item)
            self._buffer_bytes[collection_name] += item.estimated_bytes

            # Check if we should flush immediately (size or byte limit)
            should_flush = (
                len(self._buffers[collection_name]) >= self._config.size_limit
                or self._buffer_bytes[collection_name] >= self._config.byte_limit
            )

            if should_flush:
                await self._flush_collection(collection_name)

        return future

    async def flush(self) -> None:
        """Manually flush all pending items."""
        await self._flush_all()

    async def _worker(self) -> None:
        """Background worker that flushes on time trigger."""
        while not self._stop_event.is_set():
            try:
                # Wait for time limit or stop event
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=self._config.time_limit_ms / 1000.0,
                )
                break  # Stop event was set
            except asyncio.TimeoutError:
                # Time limit reached, check for items to flush
                await self._check_time_flush()

    async def _check_time_flush(self) -> None:
        """Check and flush collections that have exceeded time limit."""
        current_time = asyncio.get_event_loop().time()
        collections_to_flush = []

        async with self._lock:
            for collection_name, first_time in list(self._first_item_time.items()):
                elapsed_ms = (current_time - first_time) * 1000
                if elapsed_ms >= self._config.time_limit_ms:
                    if self._buffers.get(collection_name):
                        collections_to_flush.append(collection_name)

        for collection_name in collections_to_flush:
            async with self._lock:
                await self._flush_collection(collection_name)

    async def _flush_collection(self, collection_name: str, await_flush: bool = True) -> None:
        """Flush all items for a specific collection.

        Must be called with self._lock held.

        Args:
            await_flush: If True (default), wait for flush to complete.
                        Set to False only for fire-and-forget batching.
        """
        if collection_name not in self._buffers or not self._buffers[collection_name]:
            return

        # Take the items and reset the buffer
        items = self._buffers.pop(collection_name)
        self._buffer_bytes.pop(collection_name, None)
        self._first_item_time.pop(collection_name, None)

        # Release lock before making the RPC call
        # (We've already taken the items out of the buffer)

        # Perform flush with concurrency control
        if await_flush:
            # Default: wait for flush to complete for consistency
            await self._do_flush(collection_name, items)
        else:
            # Fire-and-forget for maximum throughput (use with caution)
            asyncio.create_task(self._do_flush(collection_name, items))

    async def _do_flush(self, collection_name: str, items: list[BatchItem]) -> None:
        """Execute the flush callback and resolve futures."""
        async with self._flush_semaphore:
            try:
                logger.debug(f"Flushing {len(items)} items to {collection_name}")
                await self._flush_callback(collection_name, items)

                # Resolve all futures on success
                for item in items:
                    if not item.future.done():
                        item.future.set_result(None)

            except Exception as e:
                logger.error(f"Batch flush failed: {e}")
                # Reject all futures on error
                for item in items:
                    if not item.future.done():
                        item.future.set_exception(e)

    async def _flush_all(self, await_flush: bool = False) -> None:
        """Flush all collections.

        Args:
            await_flush: If True, wait for each flush to complete (used during stop)
        """
        async with self._lock:
            collections = list(self._buffers.keys())

        for collection_name in collections:
            async with self._lock:
                await self._flush_collection(collection_name, await_flush=await_flush)

    def get_stats(self) -> dict:
        """Get batcher statistics for monitoring."""
        return {
            "config": {
                "size_limit": self._config.size_limit,
                "byte_limit": self._config.byte_limit,
                "time_limit_ms": self._config.time_limit_ms,
            },
            "buffers": {
                name: {
                    "count": len(items),
                    "bytes": self._buffer_bytes.get(name, 0),
                }
                for name, items in self._buffers.items()
            },
        }
