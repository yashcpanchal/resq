############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""CortexClient - Synchronous client for Cortex Vector Database.

This is a sync wrapper around AsyncCortexClient, managing an event loop
internally for blocking call semantics. Suitable for simple scripts and
applications that don't use asyncio.
"""

from __future__ import annotations

import asyncio
import atexit
import logging
import threading
from typing import Any, Optional, Union

import numpy as np

from cortex.async_client import AsyncCortexClient
from cortex.filters.dsl import Filter
from cortex.models.types import (
    CollectionStats,
    DistanceMetric,
    SearchResult,
)

logger = logging.getLogger(__name__)


class CortexClient:
    """Synchronous client for Cortex Vector Database.

    Wraps AsyncCortexClient with a managed event loop for blocking semantics.

    Example:
        with CortexClient("localhost:50051") as client:
            client.create_collection("my_vectors", dimension=128)
            client.upsert("my_vectors", id=1, vector=[0.1] * 128)
            results = client.search("my_vectors", [0.1] * 128, top_k=10)

    Note:
        For high-performance applications, consider using AsyncCortexClient
        directly with Python's asyncio.
    """

    def __init__(
        self,
        address: str,
        api_key: Optional[str] = None,
        pool_size: int = 3,
        enable_smart_batching: bool = False,  # Disabled by default for sync client
        batch_size: int = 100,
        batch_timeout_ms: int = 100,
        timeout: Optional[float] = None,
    ):
        """Initialize the sync client.

        Args:
            address: Server address in format "host:port"
            api_key: Optional API key for authentication
            pool_size: Number of gRPC channels in the pool
            enable_smart_batching: Enable automatic batching (disabled by default for sync)
            batch_size: Maximum items per batch
            batch_timeout_ms: Maximum time before flushing batch
            timeout: Default timeout for operations in seconds
        """
        self._address = address
        self._api_key = api_key
        self._pool_size = pool_size
        self._enable_smart_batching = enable_smart_batching
        self._batch_size = batch_size
        self._batch_timeout_ms = batch_timeout_ms
        self._timeout = timeout

        # Event loop management
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._loop_thread: Optional[threading.Thread] = None
        self._async_client: Optional[AsyncCortexClient] = None
        self._connected = False

    def __enter__(self) -> "CortexClient":
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()

    def connect(self) -> None:
        """Connect to the Cortex server."""
        if self._connected:
            return

        # Create a new event loop in a background thread
        self._loop = asyncio.new_event_loop()

        def run_loop():
            asyncio.set_event_loop(self._loop)
            self._loop.run_forever()

        self._loop_thread = threading.Thread(target=run_loop, daemon=True)
        self._loop_thread.start()

        # Create async client
        self._async_client = AsyncCortexClient(
            address=self._address,
            api_key=self._api_key,
            pool_size=self._pool_size,
            enable_smart_batching=self._enable_smart_batching,
            batch_size=self._batch_size,
            batch_timeout_ms=self._batch_timeout_ms,
            timeout=self._timeout,
        )

        # Connect async client
        future = asyncio.run_coroutine_threadsafe(self._async_client.connect(), self._loop)
        future.result()  # Wait for connection

        self._connected = True
        logger.info(f"Connected to Cortex at {self._address}")

        # Register cleanup on exit
        atexit.register(self.close)

    def close(self) -> None:
        """Close the connection and cleanup resources."""
        if not self._connected:
            return

        try:
            atexit.unregister(self.close)
        except Exception:
            pass

        if self._async_client and self._loop:
            try:
                future = asyncio.run_coroutine_threadsafe(self._async_client.close(), self._loop)
                future.result(timeout=5.0)
            except Exception as e:
                logger.warning(f"Error closing async client: {e}")

        if self._loop:
            self._loop.call_soon_threadsafe(self._loop.stop)
            if self._loop_thread:
                self._loop_thread.join(timeout=2.0)
            self._loop = None
            self._loop_thread = None

        self._async_client = None
        self._connected = False
        logger.info("Disconnected from Cortex")

    def _run(self, coro):
        """Run an async coroutine synchronously."""
        if not self._loop or not self._connected:
            raise RuntimeError("Client is not connected")
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result()

    # =========================================================================
    # Collection Management
    # =========================================================================

    def create_collection(
        self,
        name: str,
        dimension: int,
        distance_metric: Union[DistanceMetric, str] = DistanceMetric.COSINE,
        hnsw_m: int = 16,
        hnsw_ef_construct: int = 200,
        hnsw_ef_search: int = 50,
        config_json: Optional[str] = None,
    ) -> None:
        """Create a new collection.

        Args:
            name: Collection name
            dimension: Vector dimension
            distance_metric: Distance metric for similarity
            hnsw_m: HNSW M parameter
            hnsw_ef_construct: HNSW ef_construct parameter
            hnsw_ef_search: HNSW ef_search parameter
            config_json: Optional driver-specific configuration JSON
        """
        self._run(
            self._async_client.create_collection(
                name=name,
                dimension=dimension,
                distance_metric=distance_metric,
                hnsw_m=hnsw_m,
                hnsw_ef_construct=hnsw_ef_construct,
                hnsw_ef_search=hnsw_ef_search,
                config_json=config_json,
            )
        )

    def open_collection(self, name: str) -> None:
        """Open an existing collection."""
        self._run(self._async_client.open_collection(name))

    def close_collection(self, name: str) -> None:
        """Close a collection."""
        self._run(self._async_client.close_collection(name))

    def delete_collection(self, name: str) -> None:
        """Delete a collection."""
        self._run(self._async_client.delete_collection(name))

    def has_collection(self, name: str) -> bool:
        """Check if a collection exists.

        Args:
            name: Collection name to check

        Returns:
            True if collection exists, False otherwise
        """
        return self._run(self._async_client.has_collection(name))

    # Alias for compatibility
    collection_exists = has_collection

    def recreate_collection(
        self,
        name: str,
        dimension: int,
        distance_metric: Union[DistanceMetric, str] = DistanceMetric.COSINE,
        hnsw_m: int = 16,
        hnsw_ef_construct: int = 200,
        hnsw_ef_search: int = 50,
        config_json: Optional[str] = None,
    ) -> None:
        """Delete and recreate a collection."""
        self._run(
            self._async_client.recreate_collection(
                name=name,
                dimension=dimension,
                distance_metric=distance_metric,
                hnsw_m=hnsw_m,
                hnsw_ef_construct=hnsw_ef_construct,
                hnsw_ef_search=hnsw_ef_search,
                config_json=config_json,
            )
        )

    def get_or_create_collection(
        self,
        name: str,
        dimension: int,
        distance_metric: Union[DistanceMetric, str] = DistanceMetric.COSINE,
        hnsw_m: int = 16,
        hnsw_ef_construct: int = 200,
        hnsw_ef_search: int = 50,
        config_json: Optional[str] = None,
    ) -> bool:
        """Get existing collection or create if not exists (idempotent).

        Returns:
            True if collection was created, False if it already existed
        """
        return self._run(
            self._async_client.get_or_create_collection(
                name=name,
                dimension=dimension,
                distance_metric=distance_metric,
                hnsw_m=hnsw_m,
                hnsw_ef_construct=hnsw_ef_construct,
                hnsw_ef_search=hnsw_ef_search,
                config_json=config_json,
            )
        )

    def get_many(
        self,
        collection_name: str,
        ids: list[int],
        with_vectors: bool = True,
        with_payload: bool = True,
    ) -> list[tuple[Optional[list[float]], Optional[dict[str, Any]]]]:
        """Get multiple vectors by their IDs.

        Args:
            collection_name: Collection to get from
            ids: List of vector IDs
            with_vectors: Include vector data
            with_payload: Include payload

        Returns:
            List of (vector, payload) tuples
        """
        return self._run(
            self._async_client.get_many(
                collection_name=collection_name,
                ids=ids,
                with_vectors=with_vectors,
                with_payload=with_payload,
            )
        )

    def count(self, collection_name: str, exact: bool = True) -> int:
        """Count vectors in collection.

        Args:
            collection_name: Collection to count
            exact: If True, return exact count

        Returns:
            Number of vectors
        """
        return self._run(
            self._async_client.count(
                collection_name=collection_name,
                exact=exact,
            )
        )

    def scroll(
        self,
        collection_name: str,
        limit: int = 100,
        cursor: Optional[int] = None,
        with_vectors: bool = False,
        with_payload: bool = True,
    ) -> tuple[list[tuple[int, Optional[list[float]], Optional[dict[str, Any]]]], Optional[int]]:
        """Scroll over all vectors in collection.

        Args:
            collection_name: Collection to scroll
            limit: Records per call
            cursor: Starting ID for pagination (None = start)
            with_vectors: Include vector data
            with_payload: Include payload

        Returns:
            Tuple of (records, next_cursor)
        """
        return self._run(
            self._async_client.scroll(
                collection_name=collection_name,
                limit=limit,
                cursor=cursor,
                with_vectors=with_vectors,
                with_payload=with_payload,
            )
        )

    def list_collections(self) -> list[str]:
        """List all collections.

        Returns:
            List of collection names (TODO: requires server RPC)
        """
        return self._run(self._async_client.list_collections())

    def query(
        self,
        collection_name: str,
        filter: Optional[Union[Filter, str]] = None,
        output_fields: Optional[list[str]] = None,
        ids: Optional[list[int]] = None,
        limit: int = 100,
        skip: int = 0,
        with_vectors: bool = False,
    ) -> list[dict[str, Any]]:
        """Query for entries matching filter or IDs.

        Args:
            collection_name: Collection to query
            filter: Filter conditions (optional)
            output_fields: Fields to return (None = all payload fields)
            ids: List of IDs to retrieve (alternative to filter)
            limit: Maximum results to return
            skip: Number of records to skip for pagination
            with_vectors: Whether to return vector data

        Returns:
            List of dictionaries containing entity data

        Examples:
            >>> results = client.query("products", ids=[1, 2, 3])
            >>> results = client.query("products", limit=10)
        """
        return self._run(
            self._async_client.query(
                collection_name=collection_name,
                filter=filter,
                output_fields=output_fields,
                ids=ids,
                limit=limit,
                skip=skip,
                with_vectors=with_vectors,
            )
        )

    def describe_collection(self, collection_name: str) -> dict[str, Any]:
        """Get detailed collection information.

        Args:
            collection_name: Collection to describe

        Returns:
            Dictionary with collection details (name, status, vectors_count, etc.)

        Examples:
            >>> info = client.describe_collection("products")
            >>> print(f"Vectors: {info['vectors_count']}")
        """
        return self._run(self._async_client.describe_collection(collection_name))

    # =========================================================================
    # Data Operations
    # =========================================================================

    def upsert(
        self,
        collection_name: str,
        id: int,
        vector: Union[list[float], np.ndarray],
        payload: Optional[dict[str, Any]] = None,
    ) -> None:
        """Upsert a single vector with immediate consistency.

        Args:
            collection_name: Target collection
            id: Vector ID
            vector: Vector data
            payload: Optional JSON metadata
        """
        self._run(
            self._async_client.upsert(
                collection_name=collection_name,
                id=id,
                vector=vector,
                payload=payload,
            )
        )

    def batch_upsert(
        self,
        collection_name: str,
        ids: list[int],
        vectors: list[Union[list[float], np.ndarray]],
        payloads: Optional[list[Optional[dict[str, Any]]]] = None,
    ) -> None:
        """Batch upsert multiple vectors.

        Args:
            collection_name: Target collection
            ids: List of vector IDs
            vectors: List of vectors
            payloads: Optional list of payloads
        """
        self._run(
            self._async_client.batch_upsert(
                collection_name=collection_name,
                ids=ids,
                vectors=vectors,
                payloads=payloads,
            )
        )

    def delete(self, collection_name: str, id: int) -> None:
        """Delete a vector by ID."""
        self._run(self._async_client.delete(collection_name, id))

    def get(self, collection_name: str, id: int) -> tuple[list[float], dict[str, Any]]:
        """Get a vector by ID.

        Returns:
            Tuple of (vector, payload)
        """
        return self._run(self._async_client.get(collection_name, id))

    # =========================================================================
    # Search Operations
    # =========================================================================

    def search(
        self,
        collection_name: str,
        query: Union[list[float], np.ndarray],
        top_k: int = 10,
        filter: Optional[Union[Filter, str]] = None,
        with_payload: bool = False,
        with_vectors: bool = False,
    ) -> list[SearchResult]:
        """Search for similar vectors with optional filtering.

        Performs approximate nearest neighbor (ANN) search on the specified
        collection. Optionally applies payload-based filtering to restrict
        the search space.

        Args:
            collection_name: Name of the collection to search
            query: Query vector as a list of floats or numpy array
            top_k: Maximum number of results to return (default: 10)
            filter: Optional filter for payload-based filtering. Can be:
                - Filter object: Built using Filter().must(Field("key").eq("value"))
                - JSON string: Raw filter JSON like '{"key": "value"}'
                - None: No filtering (search all vectors)
            with_payload: If True, include payload data in results (default: False)
            with_vectors: If True, include vector data in results (default: False)

        Returns:
            List of SearchResult objects containing:
                - id: Vector ID (int)
                - score: Similarity score (lower is more similar for Euclidean)
                - payload: Dict payload if with_payload=True, else None
                - vector: List[float] if with_vectors=True, else None

        Raises:
            CortexError: If the search operation fails
            TypeError: If filter is not a Filter object or JSON string

        Example:
            >>> # Simple search
            >>> results = client.search("my_collection", query_vector, top_k=5)

            >>> # Search with Filter object
            >>> from cortex.filters import Filter, Field
            >>> f = Filter().must(Field("category").eq("electronics"))
            >>> results = client.search("my_collection", query_vector, filter=f)

            >>> # Search with payload and vectors
            >>> results = client.search(
            ...     "my_collection",
            ...     query_vector,
            ...     with_payload=True,
            ...     with_vectors=True
            ... )
        """
        return self._run(
            self._async_client.search(
                collection_name=collection_name,
                query=query,
                top_k=top_k,
                filter=filter,
                with_payload=with_payload,
                with_vectors=with_vectors,
            )
        )

    def search_filtered(
        self,
        collection_name: str,
        query: Union[list[float], np.ndarray],
        filter: Union[Filter, str],
        top_k: int = 10,
    ) -> list[SearchResult]:
        """Search with filter.

        Args:
            collection_name: Collection to search
            query: Query vector
            filter: Filter object or JSON string
            top_k: Number of results

        Returns:
            List of SearchResult
        """
        return self._run(
            self._async_client.search_filtered(
                collection_name=collection_name,
                query=query,
                filter=filter,
                top_k=top_k,
            )
        )

    def search_with_whitelist(
        self,
        collection_name: str,
        query: Union[list[float], np.ndarray],
        allowed_ids: list[int],
        top_k: int = 10,
    ) -> list[SearchResult]:
        """Search only among specified IDs.

        .. deprecated:: 0.1.0
            This method was removed from the server in v0.1.0.
            Use search() with filter conditions instead.

        Args:
            collection_name: Collection to search
            query: Query vector
            allowed_ids: List of IDs to search within
            top_k: Number of results

        Raises:
            NotImplementedError: Always raised - RPC removed from server v0.1.0
        """
        return self._run(
            self._async_client.search_with_whitelist(
                collection_name=collection_name,
                query=query,
                allowed_ids=allowed_ids,
                top_k=top_k,
            )
        )

    # =========================================================================
    # Status & Statistics
    # =========================================================================

    def get_vector_count(self, collection_name: str) -> int:
        """Get the number of vectors in a collection."""
        return self._run(self._async_client.get_vector_count(collection_name))

    def get_stats(self, collection_name: str) -> CollectionStats:
        """Get collection statistics."""
        return self._run(self._async_client.get_stats(collection_name))

    def health_check(self) -> tuple[str, int]:
        """Check server health.

        Returns:
            Tuple of (version, uptime_seconds)
        """
        return self._run(self._async_client.health_check())

    # =========================================================================
    # Maintenance
    # =========================================================================

    def flush(self, collection_name: str) -> None:
        """Flush pending writes to storage."""
        self._run(self._async_client.flush(collection_name))

    def rebuild_index(self, collection_name: str) -> None:
        """Rebuild the index for a collection.

        Note: RPC exists in proto but server returns error -1.
        """
        self._run(self._async_client.rebuild_index(collection_name))

    def optimize(self, collection_name: str) -> None:
        """Optimize the collection.

        Note: RPC exists in proto but server returns error -1.
        """
        self._run(self._async_client.optimize(collection_name))

    def save_snapshot(self, collection_name: str) -> None:
        """Save a snapshot of the collection."""
        self._run(self._async_client.save_snapshot(collection_name))

    def load_snapshot(self, collection_name: str) -> None:
        """Load a snapshot of the collection."""
        self._run(self._async_client.load_snapshot(collection_name))

    def get_state(self, collection_name: str) -> str:
        """Get collection state (READY, REBUILDING, ERROR)."""
        return self._run(self._async_client.get_state(collection_name))

    def batch_delete(self, collection_name: str, ids: list[int]) -> None:
        """Batch delete multiple vectors by ID."""
        self._run(self._async_client.batch_delete(collection_name, ids))

    # =========================================================================
    # Point Aliases
    # =========================================================================

    def insert(
        self,
        collection_name: str,
        id: int,
        vector: Union[list[float], np.ndarray],
        payload: Optional[dict[str, Any]] = None,
    ) -> None:
        """Insert a vector (alias for upsert)."""
        self.upsert(collection_name, id, vector, payload)

    def upsert_points(
        self,
        collection_name: str,
        ids: list[int],
        vectors: list[Union[list[float], np.ndarray]],
        payloads: Optional[list[Optional[dict[str, Any]]]] = None,
    ) -> None:
        """Upsert multiple points (alias for batch_upsert)."""
        self.batch_upsert(collection_name, ids, vectors, payloads)

    def retrieve(
        self,
        collection_name: str,
        ids: list[int],
        with_vectors: bool = True,
        with_payload: bool = True,
    ) -> list[tuple]:
        """Retrieve points by IDs (alias for get_many)."""
        return self.get_many(collection_name, ids, with_vectors, with_payload)

    def compact(self, collection_name: str) -> None:
        """Compact collection (alias for optimize)."""
        self.optimize(collection_name)

    # =========================================================================
    # Note: Alias Operations
    # =========================================================================

    def create_alias(self, collection_name: str, alias: str) -> None:
        """Create alias. Note: feature not yet available."""
        raise NotImplementedError("create_alias: This feature is not yet available")

    def drop_alias(self, alias: str) -> None:
        """Drop alias. Note: feature not yet available."""
        raise NotImplementedError("drop_alias: This feature is not yet available")

    def alter_alias(self, collection_name: str, alias: str) -> None:
        """Alter alias. Note: feature not yet available."""
        raise NotImplementedError("alter_alias: This feature is not yet available")

    def list_aliases(self, collection_name: str = "") -> list[str]:
        """List aliases. Note: feature not yet available."""
        raise NotImplementedError("list_aliases: This feature is not yet available")

    def describe_alias(self, alias: str) -> dict[str, Any]:
        """Describe alias. Note: feature not yet available."""
        raise NotImplementedError("describe_alias: This feature is not yet available")

    # =========================================================================
    # Note: Partition Operations
    # =========================================================================

    def create_partition(self, collection_name: str, partition_name: str) -> None:
        """Create partition. Note: feature not yet available."""
        raise NotImplementedError("create_partition: This feature is not yet available")

    def drop_partition(self, collection_name: str, partition_name: str) -> None:
        """Drop partition. Note: feature not yet available."""
        raise NotImplementedError("drop_partition: This feature is not yet available")

    def has_partition(self, collection_name: str, partition_name: str) -> bool:
        """Check partition exists. Note: feature not yet available."""
        raise NotImplementedError("has_partition: This feature is not yet available")

    def list_partitions(self, collection_name: str) -> list[str]:
        """List partitions. Note: feature not yet available."""
        raise NotImplementedError("list_partitions: This feature is not yet available")

    def load_partitions(self, collection_name: str, partitions: list[str]) -> None:
        """Load partitions. Note: feature not yet available."""
        raise NotImplementedError("load_partitions: This feature is not yet available")

    def release_partitions(self, collection_name: str, partitions: list[str]) -> None:
        """Release partitions. Note: feature not yet available."""
        raise NotImplementedError("release_partitions: This feature is not yet available")

    def get_partition_stats(self, collection_name: str, partition_name: str) -> dict:
        """Get partition stats. Note: feature not yet available."""
        raise NotImplementedError("get_partition_stats: This feature is not yet available")

    # =========================================================================
    # Note: User Operations
    # =========================================================================

    def create_user(self, username: str, password: str) -> None:
        """Create user. Note: feature not yet available."""
        raise NotImplementedError("create_user: This feature is not yet available")

    def drop_user(self, username: str) -> None:
        """Drop user. Note: feature not yet available."""
        raise NotImplementedError("drop_user: This feature is not yet available")

    def list_users(self) -> list[str]:
        """List users. Note: feature not yet available."""
        raise NotImplementedError("list_users: This feature is not yet available")

    def describe_user(self, username: str) -> dict[str, Any]:
        """Describe user. Note: feature not yet available."""
        raise NotImplementedError("describe_user: This feature is not yet available")

    def update_password(self, username: str, old_password: str, new_password: str) -> None:
        """Update password. Note: feature not yet available."""
        raise NotImplementedError("update_password: This feature is not yet available")

    # =========================================================================
    # Note: Role Operations
    # =========================================================================

    def create_role(self, role_name: str) -> None:
        """Create role. Note: feature not yet available."""
        raise NotImplementedError("create_role: This feature is not yet available")

    def drop_role(self, role_name: str) -> None:
        """Drop role. Note: feature not yet available."""
        raise NotImplementedError("drop_role: This feature is not yet available")

    def list_roles(self) -> list[str]:
        """List roles. Note: feature not yet available."""
        raise NotImplementedError("list_roles: This feature is not yet available")

    def describe_role(self, role_name: str) -> dict[str, Any]:
        """Describe role. Note: feature not yet available."""
        raise NotImplementedError("describe_role: This feature is not yet available")

    def grant_role(self, username: str, role_name: str) -> None:
        """Grant role to user. Note: feature not yet available."""
        raise NotImplementedError("grant_role: This feature is not yet available")

    def revoke_role(self, username: str, role_name: str) -> None:
        """Revoke role from user. Note: feature not yet available."""
        raise NotImplementedError("revoke_role: This feature is not yet available")

    def grant_privilege(
        self, role_name: str, object_type: str, privilege: str, object_name: str
    ) -> None:
        """Grant privilege. Note: feature not yet available."""
        raise NotImplementedError("grant_privilege: This feature is not yet available")

    def revoke_privilege(
        self, role_name: str, object_type: str, privilege: str, object_name: str
    ) -> None:
        """Revoke privilege. Note: feature not yet available."""
        raise NotImplementedError("revoke_privilege: This feature is not yet available")

    # =========================================================================
    # Note: Database Operations
    # =========================================================================

    def create_database(self, db_name: str) -> None:
        """Create database. Note: feature not yet available."""
        raise NotImplementedError("create_database: This feature is not yet available")

    def drop_database(self, db_name: str) -> None:
        """Drop database. Note: feature not yet available."""
        raise NotImplementedError("drop_database: This feature is not yet available")

    def list_databases(self) -> list[str]:
        """List databases. Note: feature not yet available."""
        raise NotImplementedError("list_databases: This feature is not yet available")

    def describe_database(self, db_name: str) -> dict[str, Any]:
        """Describe database. Note: feature not yet available."""
        raise NotImplementedError("describe_database: This feature is not yet available")

    def use_database(self, db_name: str) -> None:
        """Use database. Note: feature not yet available."""
        raise NotImplementedError("use_database: This feature is not yet available")

    # =========================================================================
    # Note: Index Operations
    # =========================================================================

    def create_payload_index(self, collection_name: str, field_name: str, field_type: str) -> None:
        """Create payload index. Note: feature not yet available."""
        raise NotImplementedError("create_payload_index: This feature is not yet available")

    def delete_payload_index(self, collection_name: str, field_name: str) -> None:
        """Delete payload index. Note: feature not yet available."""
        raise NotImplementedError("delete_payload_index: This feature is not yet available")

    def create_index(self, collection_name: str, index_params: dict, field_name: str = "") -> None:
        """Create index. Note: feature not yet available."""
        raise NotImplementedError("create_index: This feature is not yet available")

    def drop_index(self, collection_name: str, index_name: str = "") -> None:
        """Drop index. Note: feature not yet available."""
        raise NotImplementedError("drop_index: This feature is not yet available")

    def describe_index(self, collection_name: str, index_name: str = "") -> dict:
        """Describe index. Note: feature not yet available."""
        raise NotImplementedError("describe_index: This feature is not yet available")

    # =========================================================================
    # Note: Snapshot Operations
    # =========================================================================

    def create_snapshot(self, collection_name: str) -> str:
        """Create snapshot. Note: feature not yet available."""
        raise NotImplementedError("create_snapshot: This feature is not yet available")

    def list_snapshots(self, collection_name: str) -> list[dict]:
        """List snapshots. Note: feature not yet available."""
        raise NotImplementedError("list_snapshots: This feature is not yet available")

    def delete_snapshot(self, collection_name: str, snapshot_name: str) -> None:
        """Delete snapshot. Note: feature not yet available."""
        raise NotImplementedError("delete_snapshot: This feature is not yet available")

    def recover_snapshot(self, collection_name: str, snapshot_name: str) -> None:
        """Recover from snapshot. Note: feature not yet available."""
        raise NotImplementedError("recover_snapshot: This feature is not yet available")

    # =========================================================================
    # Note: Payload Operations
    # =========================================================================

    def set_payload(self, collection_name: str, id: int, payload: dict[str, Any]) -> None:
        """Set payload for a vector. Note: feature not yet available."""
        raise NotImplementedError("set_payload: This feature is not yet available")

    def delete_payload(self, collection_name: str, id: int, keys: list[str]) -> None:
        """Delete payload fields. Note: feature not yet available."""
        raise NotImplementedError("delete_payload: This feature is not yet available")

    def clear_payload(self, collection_name: str, id: int) -> None:
        """Clear all payload. Note: feature not yet available."""
        raise NotImplementedError("clear_payload: This feature is not yet available")

    def overwrite_payload(self, collection_name: str, id: int, payload: dict[str, Any]) -> None:
        """Overwrite entire payload. Note: feature not yet available."""
        raise NotImplementedError("overwrite_payload: This feature is not yet available")

    # =========================================================================
    # Note: Advanced Search
    # =========================================================================

    def query_points(
        self,
        collection_name: str,
        query: Union[list[float], np.ndarray],
        top_k: int = 10,
        filter: Optional[Union[Filter, str]] = None,
    ) -> list[SearchResult]:
        """Query points. Note: feature not yet available."""
        raise NotImplementedError("query_points: This feature is not yet available")

    def hybrid_search(
        self,
        collection_name: str,
        dense_query: list[float],
        sparse_query: Optional[dict] = None,
        top_k: int = 10,
    ) -> list[SearchResult]:
        """Hybrid search. Note: feature not yet available."""
        raise NotImplementedError("hybrid_search: This feature is not yet available")
