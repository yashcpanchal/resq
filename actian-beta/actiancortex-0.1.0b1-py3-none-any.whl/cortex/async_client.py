############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""AsyncCortexClient - Async client for Cortex Vector Database.

The async client is the core implementation, built on grpc.aio and asyncio.
It provides full async/await support with smart batching and connection pooling.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional, Sequence, Union

import numpy as np

from cortex.batcher.smart_batcher import BatcherConfig, BatchItem, SmartBatcher
from cortex.filters.dsl import Filter
from cortex.models.types import (
    CollectionState,
    CollectionStats,
    CortexError,
    DistanceMetric,
    PointRecord,
    SearchResult,
)
from cortex.proto import vdss_service_pb2 as pb
from cortex.proto import vdss_service_pb2_grpc as grpc_stub
from cortex.proto import vdss_types_pb2 as types_pb
from cortex.transport.interceptors import AuthInterceptor, RetryInterceptor
from cortex.transport.pool import ConnectionPool, PoolConfig

logger = logging.getLogger(__name__)


class AsyncCortexClient:
    """Async client for Cortex Vector Database.

    The recommended way to use this client is as an async context manager:

        async with AsyncCortexClient("localhost:50051") as client:
            await client.create_collection("my_vectors", dimension=128)
            await client.upsert("my_vectors", 1, [0.1] * 128)
            results = await client.search("my_vectors", [0.1] * 128, top_k=10)

    Features:
        - Connection pooling for high throughput
        - Smart batching for upsert operations
        - Type-safe filter DSL
        - NumPy array support
    """

    def __init__(
        self,
        address: str,
        api_key: Optional[str] = None,
        pool_size: int = 3,
        enable_smart_batching: bool = True,
        batch_size: int = 100,
        batch_timeout_ms: int = 100,
        timeout: Optional[float] = None,
    ):
        """Initialize the async client.

        Args:
            address: Server address in format "host:port"
            api_key: Optional API key for authentication
            pool_size: Number of gRPC channels in the pool
            enable_smart_batching: Enable SmartBatcher for flush() operations
            batch_size: Maximum items per batch (for SmartBatcher)
            batch_timeout_ms: Maximum time before flushing batch
            timeout: Default timeout for operations in seconds
        """
        self._address = address
        self._api_key = api_key
        self._timeout = timeout

        # Connection pool config
        self._pool_config = PoolConfig(pool_size=pool_size)

        # Smart batcher config
        self._enable_smart_batching = enable_smart_batching
        self._batcher_config = BatcherConfig(
            size_limit=batch_size,
            time_limit_ms=batch_timeout_ms,
        )

        # Runtime state (initialized on connect)
        self._pool: Optional[ConnectionPool] = None
        self._batcher: Optional[SmartBatcher] = None
        self._stub: Optional[grpc_stub.VDSSServiceStub] = None

    async def __aenter__(self) -> "AsyncCortexClient":
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()

    async def connect(self) -> None:
        """Connect to the Cortex server."""
        if self._pool is not None:
            return

        # Build interceptors
        interceptors = []
        if self._api_key:
            interceptors.append(AuthInterceptor(api_key=self._api_key))
        interceptors.append(RetryInterceptor())

        # Create connection pool
        self._pool = ConnectionPool(
            address=self._address,
            config=self._pool_config,
            interceptors=interceptors,
        )
        await self._pool.connect()

        # Create stub
        self._stub = grpc_stub.VDSSServiceStub(self._pool.get_channel())

        # Start smart batcher if enabled
        if self._enable_smart_batching:
            self._batcher = SmartBatcher(
                flush_callback=self._batch_upsert_callback,
                config=self._batcher_config,
            )
            await self._batcher.start()

        logger.info(f"Connected to Cortex at {self._address}")

    async def close(self) -> None:
        """Close the connection and cleanup resources."""
        if self._batcher:
            await self._batcher.stop(flush_remaining=True)
            self._batcher = None

        if self._pool:
            await self._pool.close()
            self._pool = None

        self._stub = None
        logger.info("Disconnected from Cortex")

    def _ensure_connected(self) -> grpc_stub.VDSSServiceStub:
        """Ensure client is connected and return stub."""
        if self._stub is None:
            raise RuntimeError("Client is not connected. Call connect() or use as context manager.")
        return self._stub

    # =========================================================================
    # Collection Management
    # =========================================================================

    async def create_collection(
        self,
        name: str,
        dimension: int,
        distance_metric: Union[DistanceMetric, str] = DistanceMetric.COSINE,
        hnsw_m: int = 16,
        hnsw_ef_construct: int = 200,
        hnsw_ef_search: int = 50,
        config_json: Optional[str] = None,
    ) -> None:
        """Create a new collection.

        Args:
            name: Collection name
            dimension: Vector dimension
            distance_metric: Distance metric for similarity (COSINE, EUCLIDEAN, DOT)
            hnsw_m: HNSW M parameter (edges per node)
            hnsw_ef_construct: HNSW ef_construct parameter
            hnsw_ef_search: HNSW ef_search parameter
            config_json: Optional driver-specific configuration JSON
        """
        stub = self._ensure_connected()

        # Map distance metric
        metric_map = {
            DistanceMetric.COSINE: types_pb.COSINE,
            DistanceMetric.EUCLIDEAN: types_pb.EUCLIDEAN,
            DistanceMetric.DOT: types_pb.DOT,
            "COSINE": types_pb.COSINE,
            "EUCLIDEAN": types_pb.EUCLIDEAN,
            "DOT": types_pb.DOT,
        }
        metric = metric_map.get(distance_metric, types_pb.COSINE)

        config = types_pb.CollectionConfig(
            dimension=dimension,
            distance_metric=metric,
            index_driver=types_pb.FAISS,
            index_algorithm=types_pb.HNSW,
            storage_type=types_pb.BTRIEVE_SPACE,
            config_json=config_json or "",
            hnsw_config=types_pb.HnswConfig(
                m=hnsw_m,
                ef_construct=hnsw_ef_construct,
                ef_search=hnsw_ef_search,
            ),
        )

        request = pb.CreateCollectionRequest(
            collection_name=name,
            config=config,
        )

        response = await stub.CreateCollection(request, timeout=self._timeout)
        self._check_status(response.status)
        logger.debug(f"Created collection: {name}")

    async def open_collection(self, name: str) -> None:
        """Open an existing collection."""
        stub = self._ensure_connected()
        request = pb.OpenCollectionRequest(collection_name=name)
        response = await stub.OpenCollection(request, timeout=self._timeout)
        self._check_status(response.status)

    async def close_collection(self, name: str) -> None:
        """Close a collection."""
        stub = self._ensure_connected()
        request = pb.CloseCollectionRequest(collection_name=name)
        response = await stub.CloseCollection(request, timeout=self._timeout)
        self._check_status(response.status)

    async def delete_collection(self, name: str) -> None:
        """Delete a collection."""
        stub = self._ensure_connected()
        request = pb.DeleteCollectionRequest(collection_name=name)
        response = await stub.DeleteCollection(request, timeout=self._timeout)
        self._check_status(response.status)
        logger.debug(f"Deleted collection: {name}")

    async def has_collection(self, name: str) -> bool:
        """Check if a collection exists .

        Args:
            name: Collection name to check

        Returns:
            True if collection exists, False otherwise

        Example:
            >>> if await client.has_collection("my_vectors"):
            ...     print("Collection exists!")
        """
        stub = self._ensure_connected()
        try:
            request = pb.OpenCollectionRequest(collection_name=name)
            response = await stub.OpenCollection(request, timeout=self._timeout)
            return response.status.code == 0
        except Exception:
            return False

    # Alias for compatibility
    collection_exists = has_collection

    async def recreate_collection(
        self,
        name: str,
        dimension: int,
        distance_metric: Union[DistanceMetric, str] = DistanceMetric.COSINE,
        hnsw_m: int = 16,
        hnsw_ef_construct: int = 200,
        hnsw_ef_search: int = 50,
        config_json: Optional[str] = None,
    ) -> None:
        """Delete and recreate a collection.

        Convenience method that deletes existing collection if it exists
        and creates a new one with the same name.

        Args:
            name: Collection name
            dimension: Vector dimension
            distance_metric: Distance metric for similarity
            hnsw_m: HNSW M parameter
            hnsw_ef_construct: HNSW ef_construct parameter
            hnsw_ef_search: HNSW ef_search parameter
            config_json: Optional driver-specific JSON config
        """
        # Try to delete existing collection (ignore errors)
        try:
            await self.delete_collection(name)
        except Exception:
            pass

        # Create new collection
        await self.create_collection(
            name=name,
            dimension=dimension,
            distance_metric=distance_metric,
            hnsw_m=hnsw_m,
            hnsw_ef_construct=hnsw_ef_construct,
            hnsw_ef_search=hnsw_ef_search,
            config_json=config_json,
        )
        logger.debug(f"Recreated collection: {name}")

    async def get_or_create_collection(
        self,
        name: str,
        dimension: int,
        distance_metric: Union[DistanceMetric, str] = DistanceMetric.COSINE,
        hnsw_m: int = 16,
        hnsw_ef_construct: int = 200,
        hnsw_ef_search: int = 50,
        config_json: Optional[str] = None,
    ) -> bool:
        """Get existing collection or create if not exists (idempotent).

        This is useful for defensive/idempotent code where you want to ensure
        a collection exists without errors if it already does.

        Args:
            name: Collection name
            dimension: Vector dimension (used only if creating)
            distance_metric: Distance metric (used only if creating)
            hnsw_m: HNSW M parameter
            hnsw_ef_construct: HNSW ef_construct parameter
            hnsw_ef_search: HNSW ef_search parameter
            config_json: Optional driver-specific JSON config

        Returns:
            True if collection was created, False if it already existed
        """
        # Check if collection exists
        if await self.has_collection(name):
            logger.debug(f"Collection '{name}' already exists")
            return False

        # Create new collection
        await self.create_collection(
            name=name,
            dimension=dimension,
            distance_metric=distance_metric,
            hnsw_m=hnsw_m,
            hnsw_ef_construct=hnsw_ef_construct,
            hnsw_ef_search=hnsw_ef_search,
            config_json=config_json,
        )
        logger.debug(f"Created collection: {name}")
        return True

    async def get_many(
        self,
        collection_name: str,
        ids: Sequence[int],
        with_vectors: bool = True,
        with_payload: bool = True,
    ) -> list[tuple[Optional[list[float]], Optional[dict[str, Any]]]]:
        """Get multiple vectors by their IDs.

        Args:
            collection_name: Collection to get from
            ids: List of vector IDs to retrieve
            with_vectors: Include vector data in response
            with_payload: Include payload in response

        Returns:
            List of (vector, payload) tuples in same order as ids.
            Returns (None, None) for IDs that don't exist.

        Example:
            >>> results = await client.get_many("my_vectors", [1, 2, 3])
            >>> for vec, payload in results:
            ...     if vec is not None:
            ...         print(f"Vector: {vec[:5]}...")
        """
        results = []
        for id in ids:
            try:
                vec, payload = await self.get(collection_name, id)
                if not with_vectors:
                    vec = None
                if not with_payload:
                    payload = None
                results.append((vec, payload))
            except Exception:
                results.append((None, None))
        return results

    # Alias for compatibility
    retrieve = get_many

    async def count(
        self,
        collection_name: str,
        exact: bool = True,
    ) -> int:
        """Count vectors in collection .

        Args:
            collection_name: Collection to count
            exact: If True, return exact count (always True for now)

        Returns:
            Number of vectors in collection

        Note:
            Filter-based counting is TODO - requires future release.
            Currently returns total vector count.
        """
        return await self.get_vector_count(collection_name)

    async def scroll(
        self,
        collection_name: str,
        limit: int = 100,
        cursor: Optional[int] = None,
        with_vectors: bool = False,
        with_payload: bool = True,
    ) -> tuple[list["PointRecord"], Optional[int]]:
        """Scroll over all vectors in collection.

        Iterate over all vectors in the collection with pagination.

        Args:
            collection_name: Collection to scroll
            limit: Maximum number of records to return per call
            cursor: Starting ID for pagination (None = start from beginning)
            with_vectors: Include vector data in response
            with_payload: Include payload in response

        Returns:
            Tuple of:
                - List of PointRecord objects
                - Next cursor for pagination (None if no more results)

        Example:
            >>> # Iterate through all vectors
            >>> next_cursor = None
            >>> while True:
            ...     records, next_cursor = await client.scroll(
            ...         "my_vectors", limit=100, cursor=next_cursor
            ...     )
            ...     for record in records:
            ...         print(f"ID: {record.id}, Payload: {record.payload}")
            ...     if next_cursor is None:
            ...         break

        Note:
            This is a client-side implementation using get().
            TODO: Implement server-side scroll RPC for better performance.
        """
        from cortex.models.types import PointRecord

        # Client-side scroll implementation
        # TODO: Replace with server-side Scroll RPC when available
        start = cursor if cursor is not None else 0
        total = await self.get_vector_count(collection_name)

        records: list[PointRecord] = []
        current = start
        end = min(start + limit, total)

        while current < end and len(records) < limit:
            try:
                vec, payload = await self.get(collection_name, current)
                record = PointRecord(
                    id=current,
                    vector=vec if with_vectors else None,
                    payload=payload if with_payload else None,
                )
                records.append(record)
            except Exception:
                pass  # Skip missing IDs
            current += 1

        next_cursor = current if current < total else None
        return records, next_cursor

    async def list_collections(self) -> list[str]:
        """List all collections .

        Returns:
            List of collection names

        Note:
            TODO: Requires ListCollections RPC on server.
            Currently not implemented - returns empty list.
        """
        # TODO: Implement when server ListCollections RPC is available
        logger.warning("list_collections() not yet implemented - requires server RPC")
        return []

    async def query(
        self,
        collection_name: str,
        filter: Optional[Union[Filter, str]] = None,
        output_fields: Optional[list[str]] = None,
        ids: Optional[list[int]] = None,
        limit: int = 100,
        skip: int = 0,
        with_vectors: bool = False,
    ) -> list[dict[str, Any]]:
        """Query for entries matching filter or IDs .

        This method retrieves entries based on filter conditions or specific IDs,
        without requiring a vector query. Similar to SQL SELECT with WHERE clause.

        Args:
            collection_name: Collection to query
            filter: Filter conditions (optional)
            output_fields: Fields to return (None = all payload fields)
            ids: List of IDs to retrieve (alternative to filter)
            limit: Maximum results to return
            skip: Number of records to skip for pagination
            with_vectors: Whether to return vector data

        Returns:
            List of dictionaries containing entity data

        Examples:
            >>> # Query by IDs
            >>> results = await client.query("products", ids=[1, 2, 3])

            >>> # Query by filter
            >>> results = await client.query("products", filter='category == "electronics"')

            >>> # Query with limit
            >>> results = await client.query("products", limit=10, with_vectors=True)
        """
        results = []

        if ids is not None:
            # Retrieve by IDs
            records = await self.get_many(
                collection_name, ids, with_vectors=with_vectors, with_payload=True
            )
            for i, (vec, payload) in enumerate(records):
                if vec is not None or payload is not None:
                    entity = {"id": ids[i]}
                    if payload:
                        entity.update(payload)
                    if with_vectors and vec is not None:
                        entity["vector"] = vec
                    results.append(entity)
        else:
            # Use scroll for filter-based query
            records, _ = await self.scroll(
                collection_name,
                limit=limit,
                cursor=skip,
                with_vectors=with_vectors,
                with_payload=True,
            )
            for record in records:
                entity = {"id": record.id}
                if record.payload:
                    entity.update(record.payload)
                if with_vectors and record.vector:
                    entity["vector"] = record.vector
                results.append(entity)

                if len(results) >= limit:
                    break

        return results[:limit]

    async def describe_collection(
        self,
        collection_name: str,
    ) -> dict[str, Any]:
        """Get detailed collection information .

        Returns comprehensive information about the collection including
        configuration, state, and statistics.

        Args:
            collection_name: Collection to describe

        Returns:
            Dictionary with collection details:
            - name: Collection name
            - status: Current state (READY, REBUILDING, etc.)
            - vectors_count: Total vector count
            - indexed_vectors_count: Number of indexed vectors
            - config: Collection configuration (dimension, metric, etc.)

        Examples:
            >>> info = await client.describe_collection("products")
            >>> print(f"Vectors: {info['vectors_count']}")
            >>> print(f"Status: {info['status']}")
        """
        # Get stats
        stats = await self.get_stats(collection_name, safe=True)

        # Get state
        state = await self.get_state(collection_name)

        result = {
            "name": collection_name,
            "status": state.value if state else "UNKNOWN",
            "vectors_count": stats.total_vectors if stats else 0,
            "indexed_vectors_count": stats.indexed_vectors if stats else 0,
            "deleted_vectors_count": stats.deleted_vectors if stats else 0,
            "storage_bytes": stats.storage_bytes if stats else 0,
            "index_memory_bytes": stats.index_memory_bytes if stats else 0,
        }

        return result

    # =========================================================================
    # Data Operations
    # =========================================================================

    async def upsert(
        self,
        collection_name: str,
        id: int,
        vector: Union[list[float], np.ndarray],
        payload: Optional[dict[str, Any]] = None,
    ) -> None:
        """Upsert a single vector with immediate consistency.

        This method uses a direct gRPC call to ensure the vector is immediately
        visible to subsequent search and count operations.

        For high-throughput bulk ingestion, use batch_upsert() instead.

        Args:
            collection_name: Target collection
            id: Vector ID
            vector: Vector data (list or numpy array)
            payload: Optional JSON metadata
        """
        # Convert numpy to list if needed
        if isinstance(vector, np.ndarray):
            vector = vector.tolist()

        # Always use direct upsert for immediate consistency
        await self._direct_upsert(collection_name, id, vector, payload)

    async def _direct_upsert(
        self,
        collection_name: str,
        id: int,
        vector: list[float],
        payload: Optional[dict[str, Any]],
    ) -> None:
        """Direct upsert without batching."""
        stub = self._ensure_connected()

        # Create VectorIdentifier for the ID
        vector_id = types_pb.VectorIdentifier(u64_id=id)

        request = pb.UpsertVectorRequest(
            collection_name=collection_name,
            vector_id=vector_id,
            vector=types_pb.Vector(data=vector),
        )

        # Only set payload if not empty
        if payload:
            request.payload.CopyFrom(types_pb.Payload(json=json.dumps(payload)))

        response = await stub.UpsertVector(request, timeout=self._timeout)
        self._check_status(response.status)

    async def _batch_upsert_callback(self, collection_name: str, items: list[BatchItem]) -> None:
        """Callback for smart batcher to flush a batch."""
        stub = self._ensure_connected()

        # Build vector_ids using VectorIdentifier
        vector_ids = [types_pb.VectorIdentifier(u64_id=item.id) for item in items]
        # Match C++ client: don't set dimension on vectors
        vectors = [types_pb.Vector(data=item.vector) for item in items]
        # Match C++ client: only set payload if not empty
        payloads = [
            types_pb.Payload(json=json.dumps(item.payload)) if item.payload else types_pb.Payload()
            for item in items
        ]

        request = pb.BatchUpsertRequest(
            collection_name=collection_name,
            vector_ids=vector_ids,
            vectors=vectors,
            payloads=payloads,
        )

        response = await stub.BatchUpsert(request, timeout=self._timeout)
        self._check_status(response.status)

    async def batch_upsert(
        self,
        collection_name: str,
        ids: list[int],
        vectors: list[Union[list[float], np.ndarray]],
        payloads: Optional[list[Optional[dict[str, Any]]]] = None,
    ) -> None:
        """Batch upsert multiple vectors directly (bypasses smart batcher).

        Args:
            collection_name: Target collection
            ids: List of vector IDs
            vectors: List of vectors
            payloads: Optional list of payloads (must match length of vectors)
        """
        stub = self._ensure_connected()

        # Build vector_ids using VectorIdentifier
        proto_vector_ids = [types_pb.VectorIdentifier(u64_id=id) for id in ids]

        # Convert numpy arrays
        proto_vectors = []
        for v in vectors:
            if isinstance(v, np.ndarray):
                v = v.tolist()
            proto_vectors.append(types_pb.Vector(data=v))

        # Handle payloads
        proto_payloads = []
        if payloads:
            for p in payloads:
                if p:
                    proto_payloads.append(types_pb.Payload(json=json.dumps(p)))
                else:
                    proto_payloads.append(types_pb.Payload())
        else:
            proto_payloads = [types_pb.Payload() for _ in vectors]

        request = pb.BatchUpsertRequest(
            collection_name=collection_name,
            vector_ids=proto_vector_ids,
            vectors=proto_vectors,
            payloads=proto_payloads,
        )

        response = await stub.BatchUpsert(request, timeout=self._timeout)
        self._check_status(response.status)

    async def batch_delete(
        self,
        collection_name: str,
        ids: list[int],
    ) -> None:
        """Batch delete multiple vectors by ID.

        Args:
            collection_name: Target collection
            ids: List of vector IDs to delete
        """
        stub = self._ensure_connected()

        # Build vector_ids using VectorIdentifier
        vector_ids = [types_pb.VectorIdentifier(u64_id=id) for id in ids]

        request = pb.BatchDeleteRequest(
            collection_name=collection_name,
            vector_ids=vector_ids,
        )

        response = await stub.BatchDelete(request, timeout=self._timeout)
        self._check_status(response.status)

    async def delete(self, collection_name: str, id: int) -> None:
        """Delete a vector by ID."""
        stub = self._ensure_connected()
        vector_id = types_pb.VectorIdentifier(u64_id=id)
        request = pb.DeleteVectorRequest(collection_name=collection_name, vector_id=vector_id)
        response = await stub.DeleteVector(request, timeout=self._timeout)
        self._check_status(response.status)

    async def get(self, collection_name: str, id: int) -> tuple[list[float], dict[str, Any]]:
        """Get a vector by ID.

        Returns:
            Tuple of (vector, payload)
        """
        stub = self._ensure_connected()
        # Create VectorIdentifier for the ID
        vector_id = types_pb.VectorIdentifier(u64_id=id)
        request = pb.GetVectorRequest(collection_name=collection_name, vector_id=vector_id)
        response = await stub.GetVector(request, timeout=self._timeout)
        self._check_status(response.status)

        return (
            list(response.vector.data),
            json.loads(response.payload.json) if response.payload.json else {},
        )

    # =========================================================================
    # Search Operations
    # =========================================================================

    async def search(
        self,
        collection_name: str,
        query: Union[list[float], np.ndarray],
        top_k: int = 10,
        filter: Optional[Union[Filter, str]] = None,
        with_payload: bool = False,
        with_vectors: bool = False,
    ) -> list[SearchResult]:
        """Search for similar vectors with optional filtering.

        Performs approximate nearest neighbor (ANN) search on the specified
        collection. Optionally applies payload-based filtering to restrict
        the search space.

        Args:
            collection_name: Name of the collection to search
            query: Query vector as a list of floats or numpy array
            top_k: Maximum number of results to return (default: 10)
            filter: Optional filter for payload-based filtering. Can be:
                - Filter object: Built using Filter().must(Field("key").eq("value"))
                - JSON string: Raw filter JSON like '{"key": "value"}'
                - None: No filtering (search all vectors)
            with_payload: If True, include payload data in results (default: False)
                         This avoids extra get() calls for payload retrieval.
            with_vectors: If True, include vector data in results (default: False)

        Returns:
            List of SearchResult objects containing:
                - id: Vector ID (int)
                - score: Similarity score (lower is more similar for Euclidean)
                - payload: Dict payload if with_payload=True, else None
                - vector: List[float] if with_vectors=True, else None

        Raises:
            CortexError: If the search operation fails
            TypeError: If filter is not a Filter object or JSON string

        Example:
            >>> # Simple search
            >>> results = await client.search("my_collection", query_vector, top_k=5)

            >>> # Search with Filter object
            >>> from cortex.filters import Filter, Field
            >>> f = Filter().must(Field("category").eq("electronics"))
            >>> results = await client.search("my_collection", query_vector, filter=f)

            >>> # Search with JSON filter string
            >>> results = await client.search(
            ...     "my_collection",
            ...     query_vector,
            ...     filter='{"category": "electronics"}'
            ... )

            >>> # Search with payload and vectors
            >>> results = await client.search(
            ...     "my_collection",
            ...     query_vector,
            ...     with_payload=True,
            ...     with_vectors=True
            ... )
            >>> for r in results:
            ...     print(f"ID: {r.id}, Score: {r.score}, Payload: {r.payload}")
        """
        stub = self._ensure_connected()

        # Convert numpy array to list
        if isinstance(query, np.ndarray):
            query = query.tolist()

        # Validate query
        if not isinstance(query, list) or len(query) == 0:
            raise ValueError("query must be a non-empty list of floats")

        # Build filter JSON string with proper type handling
        filter_json = ""
        if filter is not None:
            if isinstance(filter, Filter):
                # Filter object - convert to JSON only if non-empty
                if not filter.is_empty():
                    filter_json = filter.to_json()
                    logger.debug(f"Filter converted to JSON: {filter_json}")
            elif isinstance(filter, str):
                # JSON string - use directly (even empty string is valid)
                filter_json = filter.strip()
                # Validate it's valid JSON if non-empty
                if filter_json:
                    try:
                        json.loads(filter_json)
                    except json.JSONDecodeError as e:
                        raise ValueError(f"Invalid filter JSON string: {e}") from e
            else:
                raise TypeError(
                    f"filter must be a Filter object or JSON string, got {type(filter).__name__}"
                )

        # Build the search request
        request = pb.SearchRequest(
            collection_name=collection_name,
            query=types_pb.Vector(data=query, dimension=len(query)),
            top_k=top_k,
            with_vector=with_vectors,
            with_payload=with_payload,
        )

        # Only set filter_json if it's non-empty to avoid proto issues
        if filter_json:
            request.filter_json = filter_json

        # Execute search
        response = await stub.Search(request, timeout=self._timeout)
        self._check_status(response.status)

        # Parse results with robust field extraction
        results = []
        for r in response.results:
            result_vector = None
            result_payload = None

            # Extract vector if requested
            # Check multiple ways since protobuf field access can vary
            if with_vectors:
                try:
                    # Try direct access first
                    if r.vector and r.vector.data and len(r.vector.data) > 0:
                        result_vector = list(r.vector.data)
                except Exception:
                    # Fallback: try attribute check
                    if hasattr(r, "vector") and r.vector is not None:
                        data = getattr(r.vector, "data", None)
                        if data and len(data) > 0:
                            result_vector = list(data)

            # Extract payload if requested
            if with_payload:
                try:
                    # Try direct access first
                    if r.payload and r.payload.json:
                        payload_str = r.payload.json
                        if payload_str:
                            result_payload = json.loads(payload_str)
                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse payload JSON for ID {r.id.u64_id}: {e}")
                    result_payload = {}
                except Exception:
                    # Fallback: try attribute check
                    if hasattr(r, "payload") and r.payload is not None:
                        payload_json = getattr(r.payload, "json", None)
                        if payload_json:
                            try:
                                result_payload = json.loads(payload_json)
                            except json.JSONDecodeError:
                                result_payload = {}

            # Build result object
            result = SearchResult(
                id=r.id.u64_id,
                score=r.score,
                vector=result_vector,
                payload=result_payload,
            )
            results.append(result)

        return results

    async def search_filtered(
        self,
        collection_name: str,
        query: Union[list[float], np.ndarray],
        filter: Union[Filter, str],
        top_k: int = 10,
    ) -> list[SearchResult]:
        """Search with filter (convenience method).

        This is a convenience wrapper around search() with filter parameter.

        Args:
            collection_name: Collection to search
            query: Query vector
            filter: Filter object or JSON string
            top_k: Number of results

        Returns:
            List of SearchResult
        """
        return await self.search(
            collection_name=collection_name,
            query=query,
            top_k=top_k,
            filter=filter,
        )

    async def search_with_whitelist(
        self,
        collection_name: str,
        query: Union[list[float], np.ndarray],
        allowed_ids: list[int],
        top_k: int = 10,
    ) -> list[SearchResult]:
        """Search only among specified IDs.

        .. deprecated:: 0.1.0
            This method was removed from the server in v0.1.0.
            Use search() with filter conditions instead.

        Args:
            collection_name: Collection to search
            query: Query vector
            allowed_ids: List of IDs to search within
            top_k: Number of results

        Raises:
            NotImplementedError: Always raised - RPC removed from server v0.1.0
        """
        raise NotImplementedError(
            "SearchWithWhitelist was removed from the server in v0.1.0. "
            "Use search() with filter conditions instead."
        )

    # =========================================================================
    # Status & Statistics
    # =========================================================================

    async def get_vector_count(self, collection_name: str) -> int:
        """Get the number of vectors in a collection."""
        stub = self._ensure_connected()
        request = pb.GetVectorCountRequest(collection_name=collection_name)
        response = await stub.GetVectorCount(request, timeout=self._timeout)
        self._check_status(response.status)
        return response.count

    async def get_stats(
        self,
        collection_name: str,
        safe: bool = True,
    ) -> Optional[CollectionStats]:
        """Get collection statistics.

        Args:
            collection_name: Collection to get stats for
            safe: If True, return None on error instead of raising (default: True)

        Returns:
            CollectionStats or None if collection doesn't exist (when safe=True)
        """
        stub = self._ensure_connected()
        request = pb.GetStatsRequest(collection_name=collection_name)

        try:
            response = await stub.GetStats(request, timeout=self._timeout)
            self._check_status(response.status)
        except Exception as e:
            if safe:
                logger.debug(f"get_stats failed for '{collection_name}': {e}")
                return None
            raise

        return CollectionStats(
            total_vectors=response.stats.total_vectors,
            indexed_vectors=response.stats.indexed_vectors,
            deleted_vectors=response.stats.deleted_vectors,
            storage_bytes=response.stats.storage_bytes,
            index_memory_bytes=response.stats.index_memory_bytes,
        )

    async def get_state(self, collection_name: str) -> CollectionState:
        """Get collection state.

        Returns:
            CollectionState (READY, REBUILDING, or ERROR)
        """
        stub = self._ensure_connected()
        request = pb.GetStateRequest(collection_name=collection_name)
        response = await stub.GetState(request, timeout=self._timeout)
        self._check_status(response.status)

        # Map proto enum to Python enum
        state_map = {
            types_pb.READY: CollectionState.READY,
            types_pb.REBUILDING: CollectionState.REBUILDING,
            types_pb.ERROR: CollectionState.ERROR,
        }
        return state_map.get(response.state, CollectionState.READY)

    async def health_check(self) -> tuple[str, int]:
        """Check server health.

        Returns:
            Tuple of (version, uptime_seconds)
        """
        stub = self._ensure_connected()
        request = pb.HealthCheckRequest()
        response = await stub.HealthCheck(request, timeout=self._timeout)
        self._check_status(response.status)
        return (response.version, response.uptime_seconds)

    # =========================================================================
    # Maintenance
    # =========================================================================

    async def flush(self, collection_name: str) -> None:
        """Flush pending writes to storage."""
        # First flush smart batcher if enabled
        if self._batcher:
            await self._batcher.flush()

        stub = self._ensure_connected()
        request = pb.FlushRequest(collection_name=collection_name)
        response = await stub.Flush(request, timeout=self._timeout)
        self._check_status(response.status)

    async def rebuild_index(self, collection_name: str) -> None:
        """Rebuild the index for a collection.

        Note: This method is not yet available in the current release.
        The gRPC call is implemented correctly but the server-side
        implementation is not complete.
        """
        stub = self._ensure_connected()
        request = pb.RebuildIndexRequest(collection_name=collection_name)
        response = await stub.RebuildIndex(request, timeout=self._timeout)
        self._check_status(response.status)

    async def optimize(self, collection_name: str) -> None:
        """Optimize the collection.

        Note: This method is not yet available in the current release.
        The gRPC call is implemented correctly but the server-side
        implementation is not complete.

        This method is intended to compact storage and optimize index
        structures for better search performance.
        """
        stub = self._ensure_connected()
        request = pb.OptimizeRequest(collection_name=collection_name)
        response = await stub.Optimize(request, timeout=self._timeout)
        self._check_status(response.status)

    async def save_snapshot(self, collection_name: str) -> None:
        """Save a snapshot of the collection."""
        stub = self._ensure_connected()
        request = pb.SaveSnapshotRequest(collection_name=collection_name)
        response = await stub.SaveSnapshot(request, timeout=self._timeout)
        self._check_status(response.status)

    async def load_snapshot(self, collection_name: str) -> None:
        """Load a snapshot of the collection."""
        stub = self._ensure_connected()
        request = pb.LoadSnapshotRequest(collection_name=collection_name)
        response = await stub.LoadSnapshot(request, timeout=self._timeout)
        self._check_status(response.status)

    # =========================================================================
    # Methods planned for future releases
    # =========================================================================

    # --- Payload Operations ---
    async def set_payload(self, collection_name: str, id: int, payload: dict[str, Any]) -> None:
        """Set payload for a vector. Note: Dedicated feature not yet available."""
        raise NotImplementedError("set_payload: This feature is not yet available")

    async def delete_payload(self, collection_name: str, id: int, keys: list[str]) -> None:
        """Delete payload fields. Note: feature not yet available."""
        raise NotImplementedError("delete_payload: This feature is not yet available")

    async def clear_payload(self, collection_name: str, id: int) -> None:
        """Clear all payload. Note: feature not yet available."""
        raise NotImplementedError("clear_payload: This feature is not yet available")

    # --- Index Operations ---
    async def create_payload_index(
        self, collection_name: str, field_name: str, field_type: str
    ) -> None:
        """Create payload index. Note: feature not yet available."""
        raise NotImplementedError("create_payload_index: This feature is not yet available")

    async def delete_payload_index(self, collection_name: str, field_name: str) -> None:
        """Delete payload index. Note: feature not yet available."""
        raise NotImplementedError("delete_payload_index: This feature is not yet available")

    async def create_index(
        self, collection_name: str, field_name: str, index_type: str = "HNSW"
    ) -> None:
        """Create index . Note: feature not yet available."""
        raise NotImplementedError("create_index: This feature is not yet available")

    async def drop_index(self, collection_name: str, field_name: str) -> None:
        """Drop index . Note: feature not yet available."""
        raise NotImplementedError("drop_index: This feature is not yet available")

    async def list_indexes(self, collection_name: str) -> list[str]:
        """List indexes. Note: feature not yet available."""
        raise NotImplementedError("list_indexes: This feature is not yet available")

    # --- Snapshot Operations (Extended) ---
    async def list_snapshots(self, collection_name: str) -> list[dict[str, Any]]:
        """List snapshots. Note: feature not yet available."""
        raise NotImplementedError("list_snapshots: This feature is not yet available")

    async def create_snapshot(self, collection_name: str) -> dict[str, Any]:
        """Create snapshot . Note: feature not yet available."""
        raise NotImplementedError("create_snapshot: This feature is not yet available")

    async def delete_snapshot(self, collection_name: str, snapshot_name: str) -> None:
        """Delete snapshot. Note: feature not yet available."""
        raise NotImplementedError("delete_snapshot: This feature is not yet available")

    async def recover_snapshot(self, collection_name: str, location: str) -> None:
        """Recover from snapshot. Note: feature not yet available."""
        raise NotImplementedError("recover_snapshot: This feature is not yet available")

    # --- Alias Operations  ---
    async def create_alias(self, collection_name: str, alias: str) -> None:
        """Create alias. Note: feature not yet available."""
        raise NotImplementedError("create_alias: This feature is not yet available")

    async def drop_alias(self, alias: str) -> None:
        """Drop alias. Note: feature not yet available."""
        raise NotImplementedError("drop_alias: This feature is not yet available")

    async def alter_alias(self, collection_name: str, alias: str) -> None:
        """Alter alias. Note: feature not yet available."""
        raise NotImplementedError("alter_alias: This feature is not yet available")

    async def list_aliases(self, collection_name: str = "") -> list[str]:
        """List aliases. Note: feature not yet available."""
        raise NotImplementedError("list_aliases: This feature is not yet available")

    # --- Partition Operations  ---
    async def create_partition(self, collection_name: str, partition: str) -> None:
        """Create partition. Note: feature not yet available."""
        raise NotImplementedError("create_partition: This feature is not yet available")

    async def drop_partition(self, collection_name: str, partition: str) -> None:
        """Drop partition. Note: feature not yet available."""
        raise NotImplementedError("drop_partition: This feature is not yet available")

    async def has_partition(self, collection_name: str, partition: str) -> bool:
        """Check partition exists. Note: feature not yet available."""
        raise NotImplementedError("has_partition: This feature is not yet available")

    async def list_partitions(self, collection_name: str) -> list[str]:
        """List partitions. Note: feature not yet available."""
        raise NotImplementedError("list_partitions: This feature is not yet available")

    # --- User Management ---
    async def create_user(self, username: str, password: str) -> None:
        """Create user. Note: feature not yet available."""
        raise NotImplementedError("create_user: This feature is not yet available")

    async def drop_user(self, username: str) -> None:
        """Drop user. Note: feature not yet available."""
        raise NotImplementedError("drop_user: This feature is not yet available")

    async def list_users(self) -> list[str]:
        """List users. Note: feature not yet available."""
        raise NotImplementedError("list_users: This feature is not yet available")

    # --- Role Management ---
    async def create_role(self, role_name: str) -> None:
        """Create role. Note: feature not yet available."""
        raise NotImplementedError("create_role: This feature is not yet available")

    async def drop_role(self, role_name: str) -> None:
        """Drop role. Note: feature not yet available."""
        raise NotImplementedError("drop_role: This feature is not yet available")

    async def list_roles(self) -> list[str]:
        """List roles. Note: feature not yet available."""
        raise NotImplementedError("list_roles: This feature is not yet available")

    async def grant_role(self, username: str, role_name: str) -> None:
        """Grant role to user. Note: feature not yet available."""
        raise NotImplementedError("grant_role: This feature is not yet available")

    async def revoke_role(self, username: str, role_name: str) -> None:
        """Revoke role from user. Note: feature not yet available."""
        raise NotImplementedError("revoke_role: This feature is not yet available")

    async def describe_user(self, username: str) -> dict[str, Any]:
        """Describe user. Note: feature not yet available."""
        raise NotImplementedError("describe_user: This feature is not yet available")

    async def describe_role(self, role_name: str) -> dict[str, Any]:
        """Describe role. Note: feature not yet available."""
        raise NotImplementedError("describe_role: This feature is not yet available")

    async def update_password(self, username: str, old_password: str, new_password: str) -> None:
        """Update password. Note: feature not yet available."""
        raise NotImplementedError("update_password: This feature is not yet available")

    async def grant_privilege(
        self, role_name: str, object_type: str, object_name: str, privilege: str
    ) -> None:
        """Grant privilege. Note: feature not yet available."""
        raise NotImplementedError("grant_privilege: This feature is not yet available")

    async def revoke_privilege(
        self, role_name: str, object_type: str, object_name: str, privilege: str
    ) -> None:
        """Revoke privilege. Note: feature not yet available."""
        raise NotImplementedError("revoke_privilege: This feature is not yet available")

    async def cluster_status(self) -> dict[str, Any]:
        """Cluster status. Note: feature not yet available."""
        raise NotImplementedError("cluster_status: This feature is not yet available")

    async def describe_alias(self, alias_name: str) -> str:
        """Describe alias. Note: feature not yet available."""
        raise NotImplementedError("describe_alias: This feature is not yet available")

    async def describe_database(self, db_name: str) -> dict[str, Any]:
        """Describe database. Note: feature not yet available."""
        raise NotImplementedError("describe_database: This feature is not yet available")

    async def describe_index(self, collection_name: str, index_name: str) -> dict[str, Any]:
        """Describe index. Note: feature not yet available."""
        raise NotImplementedError("describe_index: This feature is not yet available")

    async def get_collection(self, name: str) -> dict[str, Any]:
        """Get collection info (alias for describe_collection). Note: feature not yet available."""
        return await self.describe_collection(name)

    async def load_partitions(self, collection_name: str, partition_names: list[str]) -> None:
        """Load partitions. Note: feature not yet available."""
        raise NotImplementedError("load_partitions: This feature is not yet available")

    async def release_partitions(self, collection_name: str, partition_names: list[str]) -> None:
        """Release partitions. Note: feature not yet available."""
        raise NotImplementedError("release_partitions: This feature is not yet available")

    # --- Database Management  ---
    async def create_database(self, db_name: str) -> None:
        """Create database. Note: feature not yet available."""
        raise NotImplementedError("create_database: This feature is not yet available")

    async def drop_database(self, db_name: str) -> None:
        """Drop database. Note: feature not yet available."""
        raise NotImplementedError("drop_database: This feature is not yet available")

    async def list_databases(self) -> list[str]:
        """List databases. Note: feature not yet available."""
        raise NotImplementedError("list_databases: This feature is not yet available")

    async def use_database(self, db_name: str) -> None:
        """Use database. Note: feature not yet available."""
        raise NotImplementedError("use_database: This feature is not yet available")

    # --- Advanced Search ---
    async def hybrid_search(
        self,
        collection_name: str,
        query: Union[list[float], np.ndarray],
        sparse_query: Optional[dict[str, Any]] = None,
        top_k: int = 10,
    ) -> list[SearchResult]:
        """Hybrid search. Note: feature not yet available."""
        raise NotImplementedError("hybrid_search: This feature is not yet available")

    # --- Compaction ---
    async def compact(self, collection_name: str) -> int:
        """Compact collection . Wrapper around optimize."""
        await self.optimize(collection_name)
        return 0

    async def get_compaction_state(self, job_id: int) -> str:
        """Get compaction state. Note: feature not yet available."""
        raise NotImplementedError("get_compaction_state: This feature is not yet available")

    # =========================================================================
    # Helpers
    # =========================================================================

    def _check_status(self, status: types_pb.Status) -> None:
        """Check status and raise exception on error."""
        if status.code != 0:
            raise CortexError(status.code, status.message)
