############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Generated gRPC proto stubs for VDSS service."""

# Fix relative imports for generated proto files
# IMPORTANT: vdss_types_pb2 MUST be imported first as vdss_service_pb2 depends on it
from cortex.proto import vdss_types_pb2  # noqa: F401
from cortex.proto import vdss_service_pb2, vdss_service_pb2_grpc  # noqa: F401

__all__ = [
    "vdss_types_pb2",
    "vdss_service_pb2",
    "vdss_service_pb2_grpc",
]
