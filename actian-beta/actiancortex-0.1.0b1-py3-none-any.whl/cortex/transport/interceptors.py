############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""gRPC Interceptors for authentication and observability."""

from __future__ import annotations

import logging
from typing import Awaitable, Callable, Optional

import grpc
import grpc.aio

logger = logging.getLogger(__name__)


class AuthInterceptor(grpc.aio.UnaryUnaryClientInterceptor):
    """Interceptor that injects authentication tokens into request metadata.

    Supports both static API keys and dynamic token providers (e.g., for OAuth).

    Example:
        # Static API key
        interceptor = AuthInterceptor(api_key="your-api-key")

        # Dynamic token provider (for OAuth)
        async def get_token():
            return await refresh_oauth_token()
        interceptor = AuthInterceptor(token_provider=get_token)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        token_provider: Optional[Callable[[], Awaitable[str]]] = None,
        header_key: str = "authorization",
    ):
        """Initialize the auth interceptor.

        Args:
            api_key: Static API key to include in requests
            token_provider: Async function that returns a fresh token
            header_key: Metadata key to use (default: "authorization")
        """
        if api_key and token_provider:
            raise ValueError("Specify either api_key or token_provider, not both")

        self._api_key = api_key
        self._token_provider = token_provider
        self._header_key = header_key

    async def intercept_unary_unary(
        self,
        continuation: Callable,
        client_call_details: grpc.aio.ClientCallDetails,
        request,
    ):
        """Intercept unary-unary calls to inject auth metadata."""
        # Get the token
        if self._api_key:
            token = self._api_key
        elif self._token_provider:
            token = await self._token_provider()
        else:
            # No auth configured, pass through
            return await continuation(client_call_details, request)

        # Build new metadata with auth header
        metadata = list(client_call_details.metadata or [])

        # Format as Bearer token if not already prefixed
        if not token.lower().startswith("bearer "):
            token = f"Bearer {token}"

        metadata.append((self._header_key, token))

        # Create new call details with updated metadata
        new_details = grpc.aio.ClientCallDetails(
            method=client_call_details.method,
            timeout=client_call_details.timeout,
            metadata=metadata,
            credentials=client_call_details.credentials,
            wait_for_ready=client_call_details.wait_for_ready,
        )

        return await continuation(new_details, request)


class AuthStreamInterceptor(grpc.aio.UnaryStreamClientInterceptor):
    """Auth interceptor for unary-stream calls."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        token_provider: Optional[Callable[[], Awaitable[str]]] = None,
        header_key: str = "authorization",
    ):
        self._api_key = api_key
        self._token_provider = token_provider
        self._header_key = header_key

    async def intercept_unary_stream(
        self,
        continuation: Callable,
        client_call_details: grpc.aio.ClientCallDetails,
        request,
    ):
        """Intercept unary-stream calls to inject auth metadata."""
        metadata = list(client_call_details.metadata or [])

        if self._api_key:
            token = self._api_key
        elif self._token_provider:
            token = await self._token_provider()
        else:
            return await continuation(client_call_details, request)

        if not token.lower().startswith("bearer "):
            token = f"Bearer {token}"

        metadata.append((self._header_key, token))

        new_details = grpc.aio.ClientCallDetails(
            method=client_call_details.method,
            timeout=client_call_details.timeout,
            metadata=metadata,
            credentials=client_call_details.credentials,
            wait_for_ready=client_call_details.wait_for_ready,
        )

        return await continuation(new_details, request)


class LoggingInterceptor(grpc.aio.UnaryUnaryClientInterceptor):
    """Interceptor that logs request/response metadata for debugging."""

    def __init__(self, log_level: int = logging.DEBUG):
        self._log_level = log_level

    async def intercept_unary_unary(
        self,
        continuation: Callable,
        client_call_details: grpc.aio.ClientCallDetails,
        request,
    ):
        """Log call details before and after the RPC."""
        method = client_call_details.method
        logger.log(self._log_level, f"gRPC call: {method}")

        try:
            response = await continuation(client_call_details, request)
            logger.log(self._log_level, f"gRPC response: {method} - success")
            return response
        except grpc.RpcError as e:
            logger.warning(f"gRPC error: {method} - {e.code()}: {e.details()}")
            raise


class RetryInterceptor(grpc.aio.UnaryUnaryClientInterceptor):
    """Interceptor that retries failed requests with exponential backoff.

    Only retries on transient errors (UNAVAILABLE, RESOURCE_EXHAUSTED).
    """

    def __init__(
        self,
        max_retries: int = 3,
        initial_backoff_ms: int = 100,
        max_backoff_ms: int = 5000,
        backoff_multiplier: float = 2.0,
    ):
        self._max_retries = max_retries
        self._initial_backoff_ms = initial_backoff_ms
        self._max_backoff_ms = max_backoff_ms
        self._backoff_multiplier = backoff_multiplier

        # Retryable status codes
        self._retryable_codes = {
            grpc.StatusCode.UNAVAILABLE,
            grpc.StatusCode.RESOURCE_EXHAUSTED,
            grpc.StatusCode.ABORTED,
        }

    async def intercept_unary_unary(
        self,
        continuation: Callable,
        client_call_details: grpc.aio.ClientCallDetails,
        request,
    ):
        """Retry the call with exponential backoff on transient failures."""
        import asyncio
        import random

        backoff_ms = self._initial_backoff_ms
        last_error = None

        for attempt in range(self._max_retries + 1):
            try:
                return await continuation(client_call_details, request)
            except grpc.RpcError as e:
                if e.code() not in self._retryable_codes:
                    raise

                last_error = e

                if attempt < self._max_retries:
                    # Add jitter (±25%)
                    jitter = random.uniform(0.75, 1.25)
                    sleep_ms = min(backoff_ms * jitter, self._max_backoff_ms)

                    logger.debug(
                        f"Retry {attempt + 1}/{self._max_retries} after {sleep_ms:.0f}ms: "
                        f"{e.code()}"
                    )

                    await asyncio.sleep(sleep_ms / 1000.0)
                    backoff_ms *= self._backoff_multiplier

        # All retries exhausted
        raise last_error  # type: ignore
