############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Connection pool for gRPC channels.

Manages multiple gRPC channels to bypass HTTP/2 MAX_CONCURRENT_STREAMS limit
and maximize throughput under heavy load.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Optional, Sequence

import grpc
import grpc.aio

logger = logging.getLogger(__name__)


@dataclass
class PoolConfig:
    """Configuration for the connection pool."""

    pool_size: int = 3
    """Number of channels to maintain in the pool."""

    keepalive_time_ms: int = 30000
    """Time between keepalive pings (milliseconds)."""

    keepalive_timeout_ms: int = 10000
    """Timeout for keepalive ping response (milliseconds)."""

    max_message_length: int = 100 * 1024 * 1024  # 100MB
    """Maximum message size in bytes."""

    enable_retries: bool = True
    """Enable automatic retries for transient failures."""


@dataclass
class ChannelState:
    """State tracking for a single channel."""

    channel: grpc.aio.Channel
    request_count: int = 0
    is_healthy: bool = True
    last_error: Optional[Exception] = None


class ConnectionPool:
    """Async connection pool managing multiple gRPC channels.

    Uses round-robin distribution to spread requests across channels,
    effectively multiplying the concurrent stream capacity.

    Example:
        async with ConnectionPool("localhost:50051") as pool:
            channel = pool.get_channel()
            stub = VDSSServiceStub(channel)
            response = await stub.HealthCheck(request)
    """

    def __init__(
        self,
        address: str,
        config: Optional[PoolConfig] = None,
        credentials: Optional[grpc.ChannelCredentials] = None,
        interceptors: Optional[Sequence[grpc.aio.ClientInterceptor]] = None,
    ):
        """Initialize the connection pool.

        Args:
            address: Server address in format "host:port"
            config: Pool configuration options
            credentials: Optional TLS credentials (None for insecure)
            interceptors: Optional list of gRPC interceptors
        """
        self._address = address
        self._config = config or PoolConfig()
        self._credentials = credentials
        self._interceptors = list(interceptors) if interceptors else []

        self._channels: list[ChannelState] = []
        self._current_index = 0
        self._lock = asyncio.Lock()
        self._closed = False

    async def __aenter__(self) -> "ConnectionPool":
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()

    async def connect(self) -> None:
        """Create and connect all channels in the pool."""
        if self._channels:
            return  # Already connected

        logger.info(
            f"Creating connection pool to {self._address} with {self._config.pool_size} channels"
        )

        options = self._build_channel_options()

        for i in range(self._config.pool_size):
            channel = await self._create_channel(options)
            self._channels.append(ChannelState(channel=channel))
            logger.debug(f"Created channel {i + 1}/{self._config.pool_size}")

        self._closed = False

    async def _create_channel(self, options: list[tuple]) -> grpc.aio.Channel:
        """Create a single gRPC channel with configured options."""
        if self._credentials:
            channel = grpc.aio.secure_channel(
                self._address,
                self._credentials,
                options=options,
                interceptors=self._interceptors,
            )
        else:
            channel = grpc.aio.insecure_channel(
                self._address,
                options=options,
                interceptors=self._interceptors,
            )
        return channel

    def _build_channel_options(self) -> list[tuple]:
        """Build gRPC channel options from config."""
        return [
            ("grpc.keepalive_time_ms", self._config.keepalive_time_ms),
            ("grpc.keepalive_timeout_ms", self._config.keepalive_timeout_ms),
            ("grpc.keepalive_permit_without_calls", True),
            ("grpc.max_receive_message_length", self._config.max_message_length),
            ("grpc.max_send_message_length", self._config.max_message_length),
            ("grpc.enable_retries", int(self._config.enable_retries)),
        ]

    def get_channel(self) -> grpc.aio.Channel:
        """Get a channel from the pool using round-robin selection.

        Returns:
            A gRPC channel from the pool.

        Raises:
            RuntimeError: If pool is closed or not connected.
        """
        if self._closed or not self._channels:
            raise RuntimeError("Connection pool is not connected")

        # Thread-safe round-robin without lock for performance
        index = self._current_index
        self._current_index = (index + 1) % len(self._channels)

        state = self._channels[index]
        state.request_count += 1

        return state.channel

    async def close(self) -> None:
        """Close all channels in the pool."""
        if self._closed:
            return

        self._closed = True
        logger.info(f"Closing connection pool ({len(self._channels)} channels)")

        for state in self._channels:
            try:
                await state.channel.close()
            except Exception as e:
                logger.warning(f"Error closing channel: {e}")

        self._channels.clear()

    @property
    def is_connected(self) -> bool:
        """Check if the pool has active connections."""
        return bool(self._channels) and not self._closed

    @property
    def size(self) -> int:
        """Get the number of channels in the pool."""
        return len(self._channels)

    def get_stats(self) -> dict:
        """Get pool statistics for monitoring.

        Returns:
            Dictionary with pool statistics.
        """
        return {
            "address": self._address,
            "pool_size": len(self._channels),
            "is_connected": self.is_connected,
            "channels": [
                {
                    "index": i,
                    "request_count": state.request_count,
                    "is_healthy": state.is_healthy,
                }
                for i, state in enumerate(self._channels)
            ],
        }


class SyncConnectionPool:
    """Synchronous wrapper around ConnectionPool.

    Manages an event loop internally for blocking call semantics.
    """

    def __init__(
        self,
        address: str,
        config: Optional[PoolConfig] = None,
        credentials: Optional[grpc.ChannelCredentials] = None,
    ):
        self._address = address
        self._config = config or PoolConfig()
        self._credentials = credentials
        self._channels: list[grpc.Channel] = []
        self._current_index = 0
        self._closed = False

    def __enter__(self) -> "SyncConnectionPool":
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def connect(self) -> None:
        """Create and connect all channels."""
        if self._channels:
            return

        options = [
            ("grpc.keepalive_time_ms", self._config.keepalive_time_ms),
            ("grpc.keepalive_timeout_ms", self._config.keepalive_timeout_ms),
            ("grpc.max_receive_message_length", self._config.max_message_length),
            ("grpc.max_send_message_length", self._config.max_message_length),
        ]

        for _ in range(self._config.pool_size):
            if self._credentials:
                channel = grpc.secure_channel(self._address, self._credentials, options=options)
            else:
                channel = grpc.insecure_channel(self._address, options=options)
            self._channels.append(channel)

    def get_channel(self) -> grpc.Channel:
        """Get a channel using round-robin selection."""
        if self._closed or not self._channels:
            raise RuntimeError("Connection pool is not connected")

        index = self._current_index
        self._current_index = (index + 1) % len(self._channels)
        return self._channels[index]

    def close(self) -> None:
        """Close all channels."""
        if self._closed:
            return
        self._closed = True
        for channel in self._channels:
            channel.close()
        self._channels.clear()
